export interface LoginInterface {
    userName: string;
    password: string;
}
