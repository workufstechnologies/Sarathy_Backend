export class enquiry_mode
{
    Enquiry_Mode_Id:number;
    Enquiry_Mode_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

