
export class Employer_Status
{
    Employer_Status_Id:number;
    Employer_Status_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}


