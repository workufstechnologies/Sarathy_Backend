export class Status_Type
{
    Status_Type_Id:number;
    Status_Type_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

