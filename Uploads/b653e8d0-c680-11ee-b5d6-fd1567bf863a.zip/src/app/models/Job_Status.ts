export class Job_Status
{
    Job_Status_Id:number;
    Job_Status_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

