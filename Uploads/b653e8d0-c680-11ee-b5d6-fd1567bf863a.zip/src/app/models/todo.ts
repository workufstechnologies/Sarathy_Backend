// export class todo
// {
//     todo_Id:number;
//     Student_Id:number;
//     Student_Name : string; 
//     Followup_Date : Date; 
//     todo_Status : number; 
//     Status_Name : string;
//     Remark:string;
//     To_User:number;
//     To_User_Name:string;
//     todo_Item_Id:number;
//     todo_Group_Id:number;
//     tp:number;
//     ActualFollowup_Date:Date;
//     Department_Id:number;
//     Department_Name:string;
//     todo_Details:string;
//     By_User_Id:number;
//     By_User_Name:string;
//     RowNo_sort: number;
//     RowNo:number
//     Branch_Id:number;
//     Branch_Name:string;
//     City:string;
//     Suburb:string;
//     District:string;
//     County:string;



//     Agency_Name:string;
//     Email:string;
//     Specialization:string;
//     Contact_Person:string;
//     Phone_Number: string;
//     Place:string;
//     Description:string;

// constructor(values: Object = {})  
// {
// Object.assign(this, values) 
// }
// }

export class todo
{
    todo_Id:number;
    Student_Id:number;
    Student_Name : string; 
    Followup_Date : Date; 
    todo_Status : number; 
    Status_Name : string;
    Remark:string;
    To_User:number;
    To_User_Name:string;
    todo_Item_Id:number;
    todo_Group_Id:number;
    tp:number;
    ActualFollowup_Date:Date;
    Department_Id:number;
    Department_Name:string;
    todo_Details:string;
    By_User_Id:number;
    By_User_Name:string;
    RowNo_sort: number;
    RowNo:number
    Branch_Id:number;
    Branch_Name:string;
    City:string;
    Suburb:string;
    District:string;
    County:string;
uploaded_Document:any
    Document_file:any
    Image_File_Name:string
    Image_Description:string
    Image_Path:string
    Agencies_Document_Id:number
    Agency_Name:string;
    Email:string;
    Specialization:string;
    Contact_Person:string;
    Phone_Number: string;
    Place:string;
    Description:string;
    Followp_Time:string;

    Employer_Name:string;
    Mobile:string;
    Email_Id:string;
    Contact_Person_Name:string;
    Address:string;
    todo:string;
    Country_Name:string;
    // Descriptions:string;
    Employer_Document_Id:number;
    Employer_Document_Name:string;

    Company:string;
    // Contact_Person:string;
    Phone_No:string;
    
    


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

