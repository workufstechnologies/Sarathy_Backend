export class Job_Posting
{
    Job_Posting_Id :number;
    Details :string;
    Description :string; 
    Entry_Date :Date; 
    By_User :number; 
    Job_Status:string; 
    Job_Country:string;
    Interview_Date :string = "";  
    Interview_Date_s:Date; 
    Currency:number;
    Max_Qualification_:string;
    Post_Filling_Date:string ="";
    Post_Filling_Date_s:Date;

    Job_Starting_Date:string ="";
    Job_Starting_Date_s:Date;

    Location :string; 
    Notes :string;  
    Mandatory :string; 
    Available_Vacancy:string;
    No_of_Positions:string;
    Salary:string;
    Qualification_Id:number;
    Qualification_Name:string;
    Experience_Id:number;
    Experience_Name:string;

    Employer_Id:number;
    Employer_Name:string;
    
    Job_Category_Id:number;
    Job_Category_Name:string;
    Job_Id:number;
    Job_Name:string;
    Recruitment_Fees:string;
    Student_Id:number;
    Experience_:string;

    Job_Posting_Document_Id:number;
    Job_Posting_Document_Name:string;



    uploaded_Document:any
    Document_file:any
    Image_File_Name:string
    Image_Description:string
    Image_Path:string
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

