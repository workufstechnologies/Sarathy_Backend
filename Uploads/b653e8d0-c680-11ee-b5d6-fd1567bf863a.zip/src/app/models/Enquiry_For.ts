export class Enquiry_For
{
    Enquiryfor_Id:number;
    Enquirfor_Name:string;
    Is_Check: boolean;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

