import { Student_FollowUp } from '../models/Student_FollowUp';
import { Student_Tag } from './Student_Tag';

export class Profile
{
Student_Id:number;
Student_Name:string;
Phone_Number: string;
Enquiryfor_Id:number;
Enquirfor_Name:string;
Enquiry_Mode_Id:number;
Enquiry_Mode_Name:string;
reference_id: number;
refernce: string;
Enquiry_Source_Id: number;
Enquiry_Source_Name: string;
Shore_Id:number;
Shore_Name:string;
Dob: string;
Email: string;
Unique_Id:string;
Program_Course_Id: number;
Program_Course_Name: string;
Alternative_Email: string;
Country_Id: number;
Country_Name: string;
Alternative_Phone_Number: string;
Marital_Status_Id: Number;
Marital_Status_Name: String;
Address1: string;
Address2: string;
Spouse_Name:string;
No_of_Kids_and_Age:string;
Whatsapp: string;
Date_of_Marriage:string;
Previous_Visa_Rejection:string;
Spouse_Occupation:string;
Spouse_Qualification:string;
Dropbox_Link:string;
Passport_No: string;
Passport_fromdate: string;
Passport_Todate: string;
Passport_Id: number;
Agent_Id: number;
Student_Status_Id: number;
Student_FollowUp_:Student_FollowUp
Flag_Student:number;
Flag_Followup:number;
Phone_Change:number;
Email_Change:number;
Alternative_Email_Change:number;
Alternative_Phone_Number_Change:number;
Whatsapp_Change:number;
By_User_Id:number;
Branch_Id:number;
Department_Id:number;
Transfer_Remark:string;
Class_Id:number;
Class_Name:string;
Guardian_telephone:string;
Counsilor_Note:string;
BPH_Note:string;
Pre_Visa_Note:string;
Transfer_Status_Id:number;
Transfer_Status_Name:string;
Is_Registered:number;
Status_Type_Id:number;
Status_Type_Name:string;
Color:string;
To_User_Id:number;
Refund_Amount:string;
Refund_Description:string;
Reference: String;
Educational_History: string;

Specify:string;
Reason:string;
Passport_Expirydate:Date;
Tag_Data:Student_Tag[];
Student_Tag:string;

Level_Id:number;
Level_Name:string;
Max_Qualification_Id:number;
Max_Qualification_Name:string;

Requirement_Id:number;
Requirement_Name:string;

Document_Completed:boolean;


Language_Proficiency_Id:number;
    Language_Proficiency_Name:string;

    Age_Id:number;
Age_Name:string;

Job_Category_Id:number;
Job_Category_Name:string;
Job_Id:number;
Job_Name:string;
Visa_Specify:string
Experience_Id:number;
    Experience_Name:string;

    Country_Code_Id:number;
Country_Code:string;
Preffered_Country_Id:number;
Preffered_Country_Name:string;
Visa_Category_Name:string;
Visa_Category_Id:number;
Milestone_Id:number;
Milestone_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

