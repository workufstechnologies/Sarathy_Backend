export class Visa_Type
{
    Visa_Type_Id:number;
    Visa_Type_Name:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

