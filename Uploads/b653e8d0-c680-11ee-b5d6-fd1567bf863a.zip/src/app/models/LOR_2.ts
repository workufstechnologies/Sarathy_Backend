export class LOR_2
{

LOR_2_Id:number;
LOR_2_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

