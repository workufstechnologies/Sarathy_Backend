export class Type
{
Type_Id :number; 
Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

