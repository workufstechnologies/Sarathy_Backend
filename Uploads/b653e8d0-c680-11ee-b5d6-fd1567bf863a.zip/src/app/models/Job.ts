export class Job
{
Job_Id:number;
Job_Name:string;
Employer_Name:string;
Job_Posting_Id:number;
Employer_Id:number;
Job_Category_Id:number;
Job_Category_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
