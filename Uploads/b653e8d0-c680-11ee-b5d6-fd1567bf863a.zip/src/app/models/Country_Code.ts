export class Country_Code
{
Country_Code_Id:number;
Country_Code:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}