export class Todo_Status
{
    Todo_Status_Id:number;
    Status_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}