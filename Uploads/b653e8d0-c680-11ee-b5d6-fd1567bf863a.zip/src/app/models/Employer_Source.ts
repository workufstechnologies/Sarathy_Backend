export class Employer_Source
{
    Employer_Source_Id:number;
    Employer_Source_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
