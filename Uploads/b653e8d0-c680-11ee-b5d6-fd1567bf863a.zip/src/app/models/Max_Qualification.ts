export class Max_Qualification
{
Max_Qualification_Id:number;
Max_Qualification_Name:string;
Level_Id:number;
Level_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
