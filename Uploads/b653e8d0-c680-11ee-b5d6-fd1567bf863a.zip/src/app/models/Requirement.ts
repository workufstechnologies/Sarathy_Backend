export class Requirement
{
Requirement_Id:number;
Requirement_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}