export class Interview_Status
{
    Interview_Status_Id:number;
    Interview_Status_Name:string;
   
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

