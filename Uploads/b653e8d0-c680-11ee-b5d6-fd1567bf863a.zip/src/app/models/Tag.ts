export class Tag
{
Tag_Id:number;
Tag_Name:string;
Is_Check: boolean;
Tag_Category_Id:number;
Tag_Category_Name:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

