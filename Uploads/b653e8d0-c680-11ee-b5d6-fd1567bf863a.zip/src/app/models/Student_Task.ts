// export class Student_Task
// {
//     Student_Task_Id:number;
//     Student_Id:number;
//     Student_Name : string; 
//     Followup_Date : Date; 
//     Task_Status : number; 
//     Status_Name : string;
//     Remark:string;
//     To_User:number;
//     To_User_Name:string;
//     Task_Item_Id:number;
//     Task_Group_Id:number;
//     tp:number;
//     ActualFollowup_Date:Date;
//     Department_Id:number;
//     Department_Name:string;
//     Task_Details:string;
//     By_User_Id:number;
//     By_User_Name:string;
//     RowNo_sort: number;
//     RowNo:number
//     Branch_Id:number;
//     Branch_Name:string;
//     City:string;
//     Suburb:string;
//     District:string;
//     County:string;



//     Agency_Name:string;
//     Email:string;
//     Specialization:string;
//     Contact_Person:string;
//     Phone_Number: string;
//     Place:string;
//     Description:string;

// constructor(values: Object = {})  
// {
// Object.assign(this, values) 
// }
// }

export class Student_Task
{
    Interview_Status:number;
    Interview_Status_Name:string;
    Job_Country:string;
    Student_Task_Id:number;
    Student_Id:number;
    Student_Name : string; 
    Followup_Date : Date; 
    Task_Status : number; 
    Status_Name : string;
    Remark:string;
    To_User:number;
    To_User_Name:string;
    Task_Item_Id:number;
    Task_Group_Id:number;
    tp:number;
    ActualEntry_date:Date;
    ActualFollowup_Date:Date;
    Department_Id:number;
    Department_Name:string;
    Task_Details:string;
    By_User_Id:number;
    By_User_Name:string;
    RowNo_sort: number;
    RowNo:number
    Branch_Id:number;
    Branch_Name:string;
    Employer_Status_Id:number;
    Employer_Status_Name:string;

    City:string;
    Suburb:string;
    District:string;
    County:string;
uploaded_Document:any
    Document_file:any
    Image_File_Name:string
    Image_Description:string
    Image_Path:string
    Agencies_Document_Id:number
    Agency_Name:string;
    Email:string;
    Specialization:string;
    Contact_Person:string;
    Phone_Number: string;
    Place:string;
    Description:string;
    Followp_Time:string;

    Employer_Name:string;
    Mobile:string;
    Land_Number:string;
    Email_Id:string;
    Contact_Person_Name:string;
    Address:string;
    Country_Name:string;
    // Descriptions:string;
    Employer_Document_Id:number;
    Employer_Document_Name:string;
    Employer_Source:string;
    Employer_Source_Id:number;

    Job_Category_Name:string;
    Job_Category_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

