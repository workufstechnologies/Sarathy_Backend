export class Employer
{
    Employer_Id:number;
    Employer_Name:string;
    Mobile:string;
    Email:string;
    Contact_Person:string;
    Address:string;
    Country:string;
    Description:string;
    Details:string;
    uploaded_Document:any
    Document_file:any
    Image_File_Name:string
    Image_Description:string
    Image_Path:string
    Employer_Document_Id:number
    Employer_Document_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}