export class Job_Category
{
    Job_Category_Id:number;
    Job_Category_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
