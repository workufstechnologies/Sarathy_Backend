export class Document
{
Document_Id:number;
Document_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

