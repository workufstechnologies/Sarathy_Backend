import { Student_Import_Details } from "./Student_Import_Details";
import { Student_Tag } from "./Student_Tag";
import { User_Sub } from "./User_Sub";
export class Student_Import {
	By_User_Id: number;
	Branch: number;
	Department: number;
	Status: number;
	To_User: number;
	Enquiry_Source: number;
	Enquiryfor_Id:number;
	Enquirfor_Name:string;


	Next_FollowUp_Date: Date;
	Student_Import_Details: Student_Import_Details[];
	Login_Branch: number;
	User_Sub_Data:User_Sub[]

	Tag_Data:Student_Tag[];
	Student_Tag:string;
	Entry_Date:Date;
	constructor(values: Object = {}) {
		Object.assign(this, values);
	}
}
