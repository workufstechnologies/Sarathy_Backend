export class Reference
{
Reference_Id:number;
Reference_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}