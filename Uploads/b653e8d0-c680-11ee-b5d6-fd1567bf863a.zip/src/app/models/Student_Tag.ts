export class Student_Tag
{
Student_Tag_Id:number;
Student_Id :number; 
Tag_Id :number; 
Tag_Name :string;
Is_Check:boolean=false;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

