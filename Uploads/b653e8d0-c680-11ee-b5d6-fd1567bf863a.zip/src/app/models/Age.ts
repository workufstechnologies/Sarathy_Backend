export class Age
{
Age_Id:number;
Age_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}