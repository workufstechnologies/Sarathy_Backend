export class Todo_Item
{
    Todo_Item_Id:number;
    Todo_Item_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

