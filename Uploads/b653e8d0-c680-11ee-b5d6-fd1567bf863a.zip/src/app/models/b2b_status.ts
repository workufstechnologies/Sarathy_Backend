export class b2b_status
{
    Task_Status_Id:number;
    Status_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

