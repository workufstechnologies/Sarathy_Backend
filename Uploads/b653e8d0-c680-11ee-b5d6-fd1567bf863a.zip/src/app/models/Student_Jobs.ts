export class Student_Jobs
{
    
    Student_Jobs_Id :number;
    Student_Id :number; 
    Entry_Date :Date;  
    Description :string; 
    User_Id :number; 
    Interview_Status :number; 
    Job_Id:number; 
    Job_Name:string; 
    Interview_Status_Name:string; 
    Interest_Status :number;
    Interest_Status_Name:string; 
    Visa_Status:number
    Visa_Status_Name:string;
    Employer_Id:number;
    Employer_Name:string;
    Interview_Date :string = "";  
    Interview_Date_s:Date; 
    Interview_Time:string;
    Job_Posting_Id:number;
    Job_User_Id :number;
    Job_User_Name:string; 
    Interview_Scheduled:number;
    Interview_Outcome_Id:number;
    Interview_Outcome_Name:string;
    Interview_User_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

