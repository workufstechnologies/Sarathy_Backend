export class Notification_Type {
	Notification_Type_Id: number;
	Notification_Type_Name: string;
	constructor(values: Object = {}) {
		Object.assign(this, values);
	}
}
