export class Department_Status {
    Check_Box:boolean;
    Department_Status_Id: number;
    Department_Status_Name:string;
    Status_Order: number;
    Editable: boolean;
    Color: string;
    Status_Type_Id:number;
    Status_Type_Name:string;
    Transfer_Status:boolean;
    Notification_Status:boolean;
    Registration:boolean;
    Notification_Department_Id:number;
    Notification_Department_Name:string;
    Transfer_Department_Name:string;
    Transfer_Department_Id:number;
    FollowUp:boolean;
    Display_In:number;
    Department_Status_Type:number;
    Class_Id:number;
    Class_Name:string;
    Class_Order:number;
    Registration_Mandatory:boolean;
    Update_in_Profile:boolean;
    constructor(values: Object = {}) {
        Object.assign(this, values)
    }
}

