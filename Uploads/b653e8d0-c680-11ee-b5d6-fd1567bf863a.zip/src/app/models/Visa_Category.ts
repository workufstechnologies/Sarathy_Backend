export class Visa_Category
{
    Visa_Category_Id:number;
    Visa_Category_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
