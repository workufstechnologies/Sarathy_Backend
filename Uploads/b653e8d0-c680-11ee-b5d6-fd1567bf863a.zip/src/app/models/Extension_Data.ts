export class Extension_Data
{
    Extension:number;
    Phone_No:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
