export class Milestone
{
    Milestone_Id:number;
    Milestone_Name:string;
    Entry_Date :Date;  
DeleteStatus:number;
Description:string;
Student_Id:number;
User_Id :number; 
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
