export class Country
{
Country_Id:number;
Country_Name:string;
Country_Temp:string;
Country_Code:string;
Check_Box:boolean
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

