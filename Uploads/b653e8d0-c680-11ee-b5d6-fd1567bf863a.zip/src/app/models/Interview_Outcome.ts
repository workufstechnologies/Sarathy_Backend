export class Interview_Outcome
{
    Interview_Outcome_Id:number;
    Interview_Outcome_Name:string;
   
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

