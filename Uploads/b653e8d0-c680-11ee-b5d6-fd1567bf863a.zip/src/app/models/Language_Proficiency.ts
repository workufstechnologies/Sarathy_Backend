export class Language_Proficiency
{
    Language_Proficiency_Id:number;
    Language_Proficiency_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

