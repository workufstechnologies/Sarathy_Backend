export class Application_Group
{
    Application_Group_Id:number;
    Application_Group_Name:string;
    View:boolean
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

