export class Preffered_Country
{
    Preffered_Country_Id:number;
    Preffered_Country_Name:string;
    Preffered_Country_Temp:string;
Check_Box:boolean
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

