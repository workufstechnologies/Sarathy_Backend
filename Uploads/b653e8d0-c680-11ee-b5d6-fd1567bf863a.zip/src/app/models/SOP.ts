export class SOP
{
SOP_Id:number;
SOP_Name:string;
// Ielts_Minimum_Score:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

