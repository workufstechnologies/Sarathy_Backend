export class Enquiry_Source
{
Enquiry_Source_Id:number;
Enquiry_Source_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
