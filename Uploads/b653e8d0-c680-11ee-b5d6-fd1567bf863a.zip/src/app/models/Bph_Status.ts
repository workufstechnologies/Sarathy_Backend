export class Bph_Status
{
    Bph_Status_Id:number;
    Bph_Status_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

