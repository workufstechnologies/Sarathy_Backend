import { Tag_Category_Enquiry_For } from "./Tag_Category_Enquiry_For";

export class Tag_Category
{
Tag_Category_Id:number;
Tag_Category_Name:string;
Is_Check: boolean;
Enquiry_For_Data:Tag_Category_Enquiry_For[];
Tag_Category_Enquiry_For:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
