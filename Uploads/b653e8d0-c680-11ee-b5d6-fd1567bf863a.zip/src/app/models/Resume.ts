export class Resume
{
Resume_Id:number;
Resume_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

