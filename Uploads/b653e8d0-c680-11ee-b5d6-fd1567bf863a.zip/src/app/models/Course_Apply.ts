export class Course_Apply
{
Course_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}