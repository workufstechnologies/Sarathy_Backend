export class Fees_Receipt_Status
{
    Fees_Receipt_Status_Id:number;
    Fees_Receipt_Status_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

