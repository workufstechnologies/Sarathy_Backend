export class Agent
{
    Agent_Id:number;
    Agent_Name:string;
    Phone : string; 
    Email : string; 
    Address : string; 
    Description : string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

