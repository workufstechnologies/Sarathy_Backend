export class Tag_Category_Enquiry_For
{
    Enquiryfor_Tag_Category_Id:number;
    Tag_Category_Id:number;
    Enquiryfor_Id:number;
    Enquirfor_Name:number;
    Is_Check: boolean=false;

    constructor(values: Object = {})  
    {
        Object.assign(this, values) 
    }

}
