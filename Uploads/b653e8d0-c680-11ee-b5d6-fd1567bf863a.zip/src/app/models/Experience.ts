export class Experience
{
    Experience_Id:number;
    Experience_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
