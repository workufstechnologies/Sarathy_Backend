import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Employers_Today_followupComponent } from './Employers_Today_followup.component';

describe('Tomorrows_followupComponent', () => {
  let component: Employers_Today_followupComponent;
  let fixture: ComponentFixture<Employers_Today_followupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Employers_Today_followupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Employers_Today_followupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
