/***
 * Admin module
 * Declare all componets that is used in admin module
 */
 import { NgModule } from '@angular/core';
 import { FormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
 import { RouterModule } from '@angular/router';
 import { MatTableModule, MatProgressSpinnerModule, MatDialogModule, MatAutocompleteModule, MatPaginatorModule, MatToolbarModule, MatSidenavModule, MatSortModule, MatMenuModule, MatIconModule, MatButtonModule, MatSelectModule, MatFormFieldModule, MatDatepickerModule, MatExpansionModule } from '@angular/material';
 import { MatNativeDateModule} from '@angular/material';
 import { SharedModule } from '../shared-module/shared-module';
 import { AdminRoutes } from './admin.routing';
 import { AdminComponent } from './admin.component';
 import {HttpClientModule} from '@angular/common/http';
 import { GoogleChartsModule } from 'angular-google-charts';
 import { User_DetailsComponent } from './User_Details/User_Details.component';
 import { CountryComponent } from './Country/Country.component'; 
 import { CourseComponent } from './Course/Course.component'; 
 import { Course_IntakeComponent } from './Course_Intake/Course_Intake.component'; 
 import { DocumentComponent } from './Document/Document.component';
 
 import { DurationComponent } from './Duration/Duration.component'; 
 import { IntakeComponent } from './Intake/Intake.component'; 
 import { InternshipComponent } from './Internship/Internship.component'; 
 import { Level_DetailComponent } from './Level_Detail/Level_Detail.component'; 
 import { StudentComponent } from './Student/Student.component'; 
 import { Student_DocumentComponent } from './Student_Document/Student_Document.component'; 
 import { Student_MessageComponent } from './Student_Message/Student_Message.component'; 
 import { Student_StatusComponent } from './Student_Status/Student_Status.component';
 import {Enquiry_SourceComponent } from './Enquiry_Source/Enquiry_Source.component';  
 import { SubjectComponent } from './Subject/Subject.component'; 
 import { UniversityComponent } from './University/University.component'; 
 import { AgentComponent } from './Agent/Agent.component'; 
 import { Home_PageComponent } from './Home_Page/Home_Page.component'; 
 import { DashboardComponent } from './Dashboard/Dashboard.component'; 
 import { Course_ImportComponent } from './Course_Import/Course_Import.component'; 
 import { Account_GroupComponent } from './Account_Group/Account_Group.component'; 
 import { Client_AccountsComponent } from './Client_Accounts/Client_Accounts.component';
 import { DepartmentComponent } from './Department/Department.component';
 import { Department_StatusComponent } from './Department_Status/Department_Status.component';
 import { Student_ReportComponent } from './Student_Report/Student_Report.component';
 import { Work_reportComponent } from './Work_report/Work_report.component';
 import { BranchComponent } from './Branch/Branch.component';
 import { RemarksComponent } from './Remarks/Remarks.component';
 import { TimeTrackComponent } from './TimeTrack/TimeTrack.component'; 
 import { Registration_ReportComponent } from './Registration_Report/Registration_Report.component'; 
 import { Efficiency_ReportComponent } from './Efficiency_Report/Efficiency_Report.component';
 import { Student_ImportComponent } from './Student_Import/Student_Import.component';
 import { Pending_FollowUpComponent } from './Pending_FollowUp/Pending_FollowUp.component';
 import { FeesComponent } from './Fees/Fees.component';
 import { Fees_Receipt_ReportComponent } from './Fees_Receipt_Report/Fees_Receipt_Report.component';
 import { Enquiry_Source_SummaryComponent } from './Enquiry_Source_Summary/Enquiry_Source_Summary.component';
 import { Counselor_Fees_Receipt_ReportComponent } from './Counselor_Fees_Receipt_Report/Counselor_Fees_Receipt_Report.component';
 import { Counselor_Registration_ReportComponent } from './Counselor_Registration_Report/Counselor_Registration_Report.component'
 //import { Student_Summary_ReportComponent } from './Counselor_Registration_Report/Counselor_Registration_Report.component'
 import { Student_Summary_ReportComponent } from './Student_Summary_Report/Student_Summary_Report.component';
 
 //import { Enquiry_Source_ReportComponent } from './Enquiry_Source_Report/Enquiry_Source_Report.component'; 
 
 
 import { ScrollingModule } from '@angular/cdk/scrolling';
 
 import { from } from 'rxjs';
 import { Staff_Target_ReportComponent } from './Staff_Target_Report/Staff_Target_Report.component';
 import { Student_SearchComponent } from './Student_Search/Student_Search.component';
 import { Work_SummaryComponent } from './Work_Summary/Work_Summary.component';
 import { Userwise_SummaryComponent } from './Userwise_Summary/Userwise_Summary.component';
 import { Branchwise_SummaryComponent } from './Branchwise_Summary/Branchwise_Summary.component';
 import { PageAComponent } from './PageA/PageA.component';
 import { PageCComponent } from './PageC/PageC.component';
 import { PageBComponent } from './PageB/PageB.component';
 import { Enquiry_Source_ReportComponent } from './Enquiry_Source_Report/Enquiry_Source_Report.component';
 import { Receipt_Summary_ReportComponent } from './Receipt_Summary_Report/Receipt_Summary_Report.component';
 import { Registration_SummaryComponent } from './Registration_Summary/Registration_Summary.component';
 import { Enquiry_ConversionComponent } from './Enquiry_Conversion/Enquiry_Conversion.component';
 import { Employee_SummaryComponent } from './Employee_Summary/Employee_Summary.component';
 import { User_RoleComponent } from './User_Role/User_Role.component';
 import { CompanyComponent } from './Company/Company.component';
 import { SettingsComponent } from './Settings/Settings.component';
 import { Documentation_ReportComponent } from './Documentation_Report/Documentation_Report.component';
import { Work_HistoryComponent } from './Work_History/Work_History.component';

import { Details_checkComponent } from './Details_check/Details_check.component';
import { Registration_EnquirySourceComponent } from './Registration_EnquirySource/Registration_EnquirySource.component';
import { Check_ListComponent } from './Check_List/Check_List.component';

import {Agent_DetailsComponent} from './Agent_Details/Agent_Details.component';
import { Application_ReportComponent } from './Application_Report/Application_Report.component';
import { TaskComponent } from './Task/Task.component';
import { NotificationComponent } from './Notification/Notification.component';
import { Receipt_ConfirmationComponent } from './Receipt_Confirmation/Receipt_Confirmation.component';
import { Refund_ConfirmationComponent } from './Refund_Confirmation/Refund_Confirmation.component';
import { Refund_ApprovalComponent } from './Refund_Approval/Refund_Approval.component';
import { Student_TaskComponent } from './Student_Task/Student_Task.component';
import { Application_DashboardComponent } from './Application_Dashboard/Application_Dashboard.component';
import { Passport_Expiry_ReportComponent } from './Passport_Expiry_Report/Passport_Expiry_Report.component';
import { Application_StatusComponent } from './Application_Status/Application_Status.component';
import { Task_ItemComponent } from './Task_Item/Task_Item.component';
import { Bph_ReportComponent } from './Bph_Report/Bph_Report.component';
import { Application_ListComponent } from './Application_List/Application_List.component';
import { Application_SettingsComponent } from './Application_Settings/Application_Settings.component';
import { DocumentNameComponent } from './DocumentName/DocumentName.component';
import { AccountsComponent } from './Accounts/Accounts.component';
import { Data_MigrationComponent } from './Data_Migration/Data_Migration.component';
import { Fees_Pending_ReportComponent } from './Fees_Pending_Report/Fees_Pending_Report.component';
import { Class_SummaryComponent } from './Class_Summary/Class_Summary.component';
import { ClassComponent } from './Class/Class.component';
import { Enquirywise_Status_ReportComponent } from './Enquirywise_Status_Report/Enquirywise_Status_Report.component';
import { Department_Status_ReportComponent } from './Department_Status_Report/Department_Status_Report.component';
import { FollowUp_Status_ReportComponent } from './FollowUp_Status_Report/FollowUp_Status_Report.component';
import { Department_ReportComponent } from './Department_Report/Department_Report.component';
import { Attendance_ReportComponent } from './Attendance_Report/Attendance_Report.component';
import { ReferenceComponent } from './Reference/Reference.component';
import { Student_Task_Followup_ReportComponent } from './Student_Task_Followup_Report/Student_Task_Followup_Report.component';
import { TagComponent } from './Tag/Tag.component';
import { Tag_CategoryComponent } from './Tag_Category/Tag_Category.component';
import { Max_Qualification } from 'app/models/Max_Qualification';
import { Max_QualificationComponent } from './Max_Qualification/Max_Qualification.component';
import { LevelComponent } from './Level/Level.component';
import { Job_PostingComponent } from './Job_Posting/Job_Posting.component';
import { Agent_DataComponent } from './Agent_Data/Agent_Data.component';
import { Job_CategoryComponent } from './Job_Category/Job_Category.component';
import { JobComponent } from './Job/Job.component';
import { Pending_Fees_ReportComponent } from './Pending_Fees_Report/Pending_Fees_Report.component';
import { Enquiry_reportComponent } from './Enquiry_report/Enquiry_report.component';
import { Chat_WindowComponent } from './Chat_Window/Chat_Window.component';
import { B2B_AgenciesComponent } from './B2B_Agencies/B2B_Agencies.component';
import { Work_Details_ReportComponent } from './Work_Details_Report/Work_Details_Report.component';
import { EmployerComponent } from './Employer/Employer.component';
import { Job_SummaryComponent } from './Job_Summary/Job_Summary.component';
import { Interview_ReportComponent } from './Interview_Report/Interview_Report.component';
import { Pending_Task_ReportComponent } from './Pending_Task_Report/Pending_Task_Report.component';
import { Employer_DetailsComponent } from './Employer_Details/Employer_Details.component';
import { Tomorrows_followupComponent } from './Tomorrows_followup/Tomorrows_followup.component';
import { Employer_DashboardComponent } from './Employer_Dashboard/Employer_Dashboard.component';
import { Employer_Pending_FollowUpComponent } from './Employer_Pending_FollowUp/Employer_Pending_FollowUp.component';
import { Employers_Tomorrows_followupComponent } from './Employers_Tomorrows_followup/Employers_Tomorrows_followup.component';
import { Employers_Today_followupComponent } from './Employers_Today_followup/Employers_Today_followup.component';
import { TodoComponent } from './Todo/Todo.component';
import { Agreed_EmployerComponent } from './Agreed_Employer/Agreed_Employer.component';
import { Candidate_Document_ReportComponent } from './Candidate_Document_Report/Candidate_Document_Report.component';
import { Monthly_Sales_ReportComponent } from './Monthly_Sales_Report/Monthly_Sales_Report.component';
import { Job_Interview_ReportComponent } from './Job_Interview_Report/Job_Interview_Report.component';
import { Meeting_FollowupComponent } from './Meeting Followup/Meeting_Followup.component';
import { Pending_Interview_ReportComponent } from './Pending_Interview_Report/Pending_Interview_Report.component';
import { Visa_ReportComponent } from './Visa_Report/Visa_Report.component';
import { Job_DashboardComponent } from './Job_Dashboard/Job_Dashboard.component';
import { Interview_Outcome_ReportComponent } from './Interview_Outcome_Report/Interview_Outcome_Report.component';
import { MilestoneComponent } from './Milestone/Milestone.component';



 @NgModule({
   imports: [ 
     RouterModule.forChild(AdminRoutes),
     SharedModule,
     MatTableModule,HttpClientModule,
     MatPaginatorModule,
     MatSortModule
   , MatIconModule,
     MatMenuModule,GoogleChartsModule,
     MatSelectModule
     , MatButtonModule
     , MatDialogModule
     , MatToolbarModule, MatExpansionModule
     , MatSidenavModule
     , MatAutocompleteModule
     , MatProgressSpinnerModule
     ,MatFormFieldModule,
     MatDatepickerModule,
     ScrollingModule,
     FormsModule,
     HttpModule
    
   ],
   declarations: [AdminComponent,BranchComponent,DepartmentComponent,
     CountryComponent,Department_StatusComponent,
     CourseComponent,
     Course_IntakeComponent,
     DocumentComponent,Student_ReportComponent,Work_reportComponent,
     DurationComponent,
     IntakeComponent,
     InternshipComponent,
     Level_DetailComponent,
     StudentComponent,
     Student_DocumentComponent,
     Enquiry_SourceComponent,
     Enquiry_SourceComponent,
     Student_MessageComponent,
     Student_StatusComponent,
     SubjectComponent,
     AgentComponent,
     Home_PageComponent,
      DashboardComponent,
     UniversityComponent,
     Course_ImportComponent,
     Account_GroupComponent,
     Client_AccountsComponent,
     RemarksComponent,
     TimeTrackComponent,
     Registration_ReportComponent,
     Efficiency_ReportComponent,
     Student_ImportComponent,
     Pending_FollowUpComponent,
     FeesComponent,
     Fees_Receipt_ReportComponent,
     Enquiry_Source_SummaryComponent,
     Counselor_Fees_Receipt_ReportComponent,
     Counselor_Registration_ReportComponent,
     Student_Summary_ReportComponent,
     Staff_Target_ReportComponent,
     Student_SearchComponent,
     Work_SummaryComponent,
     Userwise_SummaryComponent,
     Branchwise_SummaryComponent,
     PageAComponent,
     PageCComponent,
     PageBComponent,
     Enquiry_Source_ReportComponent,
     Receipt_Summary_ReportComponent,
     Registration_SummaryComponent,
     Enquiry_ConversionComponent,
     Employee_SummaryComponent,
     User_RoleComponent,
     CompanyComponent,
     SettingsComponent,
     Documentation_ReportComponent,
     Work_HistoryComponent,
     Registration_EnquirySourceComponent,
     Details_checkComponent,
     Check_ListComponent,
     Agent_DetailsComponent,
     Application_ReportComponent,
     TaskComponent,
     NotificationComponent,
     Receipt_ConfirmationComponent,
     Refund_ConfirmationComponent,
     Refund_ApprovalComponent,
     Application_DashboardComponent,
     Student_TaskComponent ,
     Passport_Expiry_ReportComponent,
     Application_StatusComponent,
     Task_ItemComponent,
     Bph_ReportComponent,
     Application_ListComponent,
     //Enquiry_Source_ReportComponent,
      User_DetailsComponent,
    Application_SettingsComponent,
    DocumentNameComponent,
    AccountsComponent,
    Data_MigrationComponent,
    Fees_Pending_ReportComponent,
    Class_SummaryComponent,
    ClassComponent,
    Enquirywise_Status_ReportComponent,
    Department_Status_ReportComponent,
    FollowUp_Status_ReportComponent,
    Department_ReportComponent,
    Attendance_ReportComponent,
    ReferenceComponent,
    Student_Task_Followup_ReportComponent,

    TagComponent,
    Tag_CategoryComponent,
    Max_QualificationComponent,
    LevelComponent,
    Job_PostingComponent,Agent_DataComponent,Job_CategoryComponent,EmployerComponent,JobComponent,Pending_Fees_ReportComponent,Enquiry_reportComponent,
    Chat_WindowComponent,B2B_AgenciesComponent,Work_Details_ReportComponent,Job_SummaryComponent,Interview_ReportComponent,Pending_Task_ReportComponent,
    Employer_DetailsComponent,Tomorrows_followupComponent,Employer_DashboardComponent,Employer_Pending_FollowUpComponent,
    Employers_Tomorrows_followupComponent,Employers_Today_followupComponent,TodoComponent,Agreed_EmployerComponent,Candidate_Document_ReportComponent,
    Monthly_Sales_ReportComponent,
    Job_Interview_ReportComponent,Meeting_FollowupComponent,Pending_Interview_ReportComponent,Visa_ReportComponent,Job_DashboardComponent,Interview_Outcome_ReportComponent,
    MilestoneComponent
  ],
 })
 
 export class AdminModule { }
 