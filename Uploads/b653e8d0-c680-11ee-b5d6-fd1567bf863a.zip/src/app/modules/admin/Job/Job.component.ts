import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Job} from '../../../models/Job';
import { Job_Service } from '../../../services/Job.Service';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Language_Proficiency } from 'app/models/Language_Proficiency';

import { Job_Category } from 'app/models/Job_Category';
import { Job_Category_Service } from 'app/services/Job_Category.Service';


@Component({
selector: 'app-Job',
templateUrl: './Job.component.html',
styleUrls: ['./Job.component.css']
})
export class JobComponent implements OnInit {
Job_Data:Job[]
Job_:Job= new Job();

Job_Name_Search:string;


Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Job_Edit:boolean;
Job_Save:boolean;
Job_Delete:boolean;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";


Job_Category_1_Data: Job_Category[];
	Job_Category_1_Data_Filter: Job_Category[];
	Job_Category_1_: Job_Category = new Job_Category();
	Job_Category_1_Temp_: Job_Category = new Job_Category();



constructor(public Job_Service_:Job_Service,public Job_Category_Service_: Job_Category_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));


    {

     this.Page_Load()
    }
}


Page_Load()
{
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 250;
    this.Clr_Job();
    this.Get_Menu_Status(137,this.Login_User);

    this.Search_Job();
    this.Entry_View=false;

    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 200;
    this.myTotalHeight=this.myTotalHeight-90;
    this.myInnerHeight = this.myInnerHeight - 230;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
this.issLoading = true;
this.Job_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            
  
    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==137)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==137)
        {
            
        

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
                this.Job_Edit=this.Permissions.Edit;
                this.Job_Save=this.Permissions.Save;
                this.Job_Delete=this.Permissions.Delete;
    
        }

    }

},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}


Create_New()
    {
        this.Entry_View = true;
        this.Clr_Job();
    }

Close_Click()
    {
        this.Entry_View = false;
    }

trackByFn(index, item) 
    {
        return index;
    }


 Clr_Job()
 {
this.Job_.Job_Id=0;
this.Job_.Job_Name="";
this.Job_Category_1_=null;


}
Search_Job()
{
this.issLoading=true;
debugger;
this.Job_Service_.Search_Job(this.Job_Name_Search).subscribe(Rows => 
    {
debugger;
    this.Job_Data=Rows[0];
    this.Total_Entries=this.Job_Data.length;
    if(this.Job_Data.length==0)
    {
        this.issLoading=false;
        const dialogRef = this.dialogBox.open
        (DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
    }
    this.issLoading=false;
    },
    Rows => { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            });
}

Delete_Job(Job_Id,index)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
    this.Search_Job();
    dialogRef.afterClosed().subscribe(result =>
    {
        if(result=='Yes')
        {
            this.issLoading=true;
            this.Job_Service_.Delete_Job(Job_Id).subscribe(Delete_status => 
                {
                    if(Number(Delete_status[0][0].Job_Id_)>0)
                    {
                        this.Job_Data.splice(this.EditIndex, 1);
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
                        this.Search_Job();
                    }
                    else if(Number(Delete_status[0][0].Job_Id_)== -2)
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
                    }
                    else
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                    }
                    this.issLoading=false;
                },
                Rows => { 
                            this.issLoading=false;
                            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                        });
        }
    });
}


Save_Job()
{
    if (this.Job_.Job_Name == undefined || this.Job_.Job_Name== null || this.Job_.Job_Name == undefined || this.Job_.Job_Name=='') 
    {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Job', Type: "3" } });
        return;
    }



    if (
        this.Job_Category_1_ == undefined ||
        this.Job_Category_1_ == null ||
        this.Job_Category_1_.Job_Category_Id == undefined ||
        this.Job_Category_1_.Job_Category_Id == 0
    ) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Select Job_Category", Type: "3" },
        });
        return;
    }



    this.Job_.Job_Category_Id=this.Job_Category_1_.Job_Category_Id;
    this.Job_.Job_Category_Name=this.Job_Category_1_.Job_Category_Name;

    debugger;
    this.issLoading=true;
    this.Job_Service_.Save_Job(this.Job_).subscribe(Save_status => 
        {
            debugger;
            Save_status=Save_status[0];
            if(Number(Save_status[0].Job_Id_)>0)
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
                this.Search_Job();
                this.Clr_Job();
            }
            else
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            }   
            this.issLoading=false;
        },
        Rows => 
        { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error,Type:"2"}});
        });
}


Edit_Job(Job_e:Job,index)
{  

    debugger
    this.Entry_View=true;
    this.Job_=Job_e;
    this.Job_=Object.assign({},Job_e);

    this.Job_Category_1_Temp_.Job_Category_Id = Job_e.Job_Category_Id;
    this.Job_Category_1_Temp_.Job_Category_Name = Job_e.Job_Category_Name;
    this.Job_Category_1_ = Object.assign({}, this.Job_Category_1_Temp_);




}



Search_Job_Category_Typeahead(event: any) {
		
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Job_Category_1_Data=[]

    if (this.Job_Category_1_Data == undefined || this.Job_Category_1_Data.length == 0) {
        this.issLoading = true;

        this.Job_Category_Service_.Search_Job_Category_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Job_Category_1_Data = Rows[0];
                    this.Job_Category_1_Data_Filter = [];
                    for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
                        if (
                            this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value)
                        )
                            this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Job_Category_1_Data_Filter = [];
        for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
            if (this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value))
                this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
        }
    }
}

display_Job_Category(Job_Category_e: Job_Category) 
{
    if (Job_Category_e) {
        return Job_Category_e.Job_Category_Name;
    }
}


}



