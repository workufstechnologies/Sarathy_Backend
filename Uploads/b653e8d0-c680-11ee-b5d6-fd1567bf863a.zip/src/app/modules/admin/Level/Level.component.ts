import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Level} from '../../../models/Level';
import { Level_Service } from '../../../services/Level.Service';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';


@Component({
selector: 'app-Level',
templateUrl: './Level.component.html',
styleUrls: ['./Level.component.css']
})
export class LevelComponent implements OnInit {
Level_Data:Level[]
Level_:Level= new Level();

Level_Name_Search:string;


Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Level_Edit:boolean;
Level_Save:boolean;
Level_Delete:boolean;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";

constructor(public Level_Service_:Level_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));


    {

     this.Page_Load()
    }
}


Page_Load()
{
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 250;
    this.Clr_Level();
    this.Get_Menu_Status(138,this.Login_User);

    this.Search_Level();
    this.Entry_View=false;

    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 200;
    this.myTotalHeight=this.myTotalHeight-90;
    this.myInnerHeight = this.myInnerHeight - 230;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
this.issLoading = true;
this.Level_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            
  
    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==138)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==138)
        {
            
        

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
                this.Level_Edit=this.Permissions.Edit;
                this.Level_Save=this.Permissions.Save;
                this.Level_Delete=this.Permissions.Delete;
    
        }

    }

},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}


Create_New()
    {
        this.Entry_View = true;
        this.Clr_Level();
    }

Close_Click()
    {
        this.Entry_View = false;
    }

trackByFn(index, item) 
    {
        return index;
    }


 Clr_Level()
 {
this.Level_.Level_Id=0;
this.Level_.Level_Name="";


}
Search_Level()
{
this.issLoading=true;

this.Level_Service_.Search_Level(this.Level_Name_Search).subscribe(Rows => 
    {

    this.Level_Data=Rows[0];
    this.Total_Entries=this.Level_Data.length;
    if(this.Level_Data.length==0)
    {
        this.issLoading=false;
        const dialogRef = this.dialogBox.open
        (DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
    }
    this.issLoading=false;
    },
    Rows => { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            });
}

Delete_Level(Level_Id,index)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
    this.Search_Level();
    dialogRef.afterClosed().subscribe(result =>
    {
        if(result=='Yes')
        {
            this.issLoading=true;
            this.Level_Service_.Delete_Level(Level_Id).subscribe(Delete_status => 
                {
                    if(Number(Delete_status[0][0].Level_Id_)>0)
                    {
                        this.Level_Data.splice(this.EditIndex, 1);
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
                        this.Search_Level();
                    }
                    else if(Number(Delete_status[0][0].Level_Id_)== -2)
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
                    }
                    else
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                    }
                    this.issLoading=false;
                },
                Rows => { 
                            this.issLoading=false;
                            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                        });
        }
    });
}


Save_Level()
{
    if (this.Level_.Level_Name == undefined || this.Level_.Level_Name== null || this.Level_.Level_Name == undefined || this.Level_.Level_Name=='') 
    {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Enquiry Source', Type: "3" } });
        return;
    }
    
    this.issLoading=true;
    this.Level_Service_.Save_Level(this.Level_).subscribe(Save_status => 
        {
            Save_status=Save_status[0];
            if(Number(Save_status[0].Level_Id_)>0)
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
                this.Search_Level();
                this.Clr_Level();
            }
            else
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            }   
            this.issLoading=false;
        },
        Rows => 
        { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error,Type:"2"}});
        });
}


Edit_Level(Level_e:Level,index)
{  
    this.Entry_View=true;
    this.Level_=Level_e;
    this.Level_=Object.assign({},Level_e);
}

}



