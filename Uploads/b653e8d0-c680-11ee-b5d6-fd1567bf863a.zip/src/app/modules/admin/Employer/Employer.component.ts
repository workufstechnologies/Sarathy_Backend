import { Component, OnInit,Input,Injectable, ErrorHandler } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of as observableOf, merge, throwError } from 'rxjs';
import { Job_Posting_Service } from '../../../services/Job_Posting.Service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Job_Posting} from '../../../models/Job_Posting';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogConfig, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS} from '@angular/material';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';
import { getParseErrors, syntaxError } from '@angular/compiler';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component'
//import { ConsoleReporter } from 'jasmine';
import { error } from '@angular/compiler/src/util';
import { Sub_Status } from 'app/models/Sub_Status';
import { Job_Status } from 'app/models/Job_Status';
import { User_Details } from 'app/models/User_Details';
import { Student_Service } from 'app/services/Student.Service';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { environment } from 'environments/environment';
import * as io from "socket.io-client";
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { event } from 'jquery';
import { Max_Qualification } from 'app/models/Max_Qualification';
import { Max_Qualification_Service } from 'app/services/Max_Qualification.Service';
import { Experience } from 'app/models/Experience';
import { University_Service } from 'app/services/University.service';
import { Employer } from 'app/models/Employer';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
parse: {
dateInput: 'DD/MM/YYYY',
},
display: {
dateInput: 'DD/MM/YYYY',monthYearLabel: 'MMM YYYY',dateA11yLabel: 'DD/MM/YYYY',monthYearA11yLabel: 'MMMM YYYY',
},
};

@Component({
selector: 'app-Employer',
templateUrl: './Employer.component.html',
styleUrls: ['./Employer.component.css'],
providers: [
    {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
],
})
export class  EmployerComponent implements OnInit {

url = environment.NotificationPath; // 'http://regnewapi.trackbox.co.in:3646/'
private socket;
Employer_Data:Employer[];
Employer_:Employer= new Employer;
Job_Posting_Data:Job_Posting[]
Job_Posting_:Job_Posting= new Job_Posting();
Job_Posting_Name_Search:string;
Entry_View:boolean=true;
Sub_Status_View:boolean=true;
Status_View:boolean=true;
EditIndex: number;
Menu_Id:number=114;
color = 'primary';
mode = 'indeterminate';
value = 50;Total_Entries:Number;
issLoading: boolean;
Job_Posting_Edit:boolean;
Job_Posting_Save:boolean;
Job_Posting_Delete:boolean;
array:any;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";
Permissions: any;
Job_Posting_Data1:Job_Posting[]
Employer_Edit:boolean;
Employer_Delete:boolean;
Sub_Status_Data:Sub_Status[]
Sub_Status_:Sub_Status= new Sub_Status();
Sub_Status_Search:string;
Employer_Name_Search:string;
Add_Document_view: boolean = false;
file_b2b_changed: boolean=false;
Max_Qualification_Data: Max_Qualification[];
	Max_Qualification_Data_Filter: Max_Qualification[];
	Max_Qualification_: Max_Qualification = new Max_Qualification();
	Max_Qualification_Temp_: Max_Qualification = new Max_Qualification();

    // Employer_: Employer = new Employer();
	Employer_Temp: Employer = new Employer();
	// Employer_Data: Employer[];


// Status_Type_:number=0;


// Job_Status_: Job_Status = new Job_Status();
// Job_Status_Temp: Job_Status = new Job_Status();
// Job_Status_Data: Job_Status[];

Job_Status_ :number =0;

Users_Data: User_Details[];
Users_Temp: User_Details = new User_Details();
User_Search: User_Details = new User_Details();

Search_FromDate: Date = new Date();
Search_ToDate: Date = new Date();
Look_In_Date: Boolean = true;

year: any;
month: any;
day: any;
date: any;

Search_JobName:string="";

Job_Data: Job_Posting[];
Job_Data_Filter: Job_Posting[];
Job_Temp: Job_Posting = new Job_Posting();
Job_: Job_Posting = new Job_Posting();

Experience_Data: Experience[];
	Experience_Data_Filter: Experience[];
	Experience_: Experience = new Experience();
	Experience__Temp_: Experience = new Experience();



constructor(public Student_Service_:Student_Service,public University_Service_: University_Service,public Job_Posting_Service_:Job_Posting_Service,public Max_Qualification_Service_: Max_Qualification_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) {
    this.socket = io(this.url, {
        transports: ["websocket"],
        auth: {
            token: localStorage.getItem("token"),
        },
    });
    this.socket = io(this.url);
} 
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));

    // this.array=Get_Page_Permission(this.Menu_Id);
    // if(this.array==undefined || this.array==null)
    // {
    // localStorage.removeItem('token');
    // this.router.navigateByUrl('/auth/login');
    // }
    // else 
    {
    // this.Job_Posting_Edit= this.array.Edit;
    // this.Job_Posting_Save= this.array.Save;
    // this.Job_Posting_Delete= this.array.Delete;
this.Page_Load()
}}
Page_Load()
{
    this.Get_Menu_Status(139,this.Login_User); 
	this.myInnerHeight = window.innerHeight;
    this.myTotalHeight = this.myInnerHeight;
    this.myTotalHeight = this.myTotalHeight - 280;
    this.myInnerHeight = this.myInnerHeight - 210;
    
    this.Get_Lead_Load_Data_ByUser(this.Login_User);
    this.Clr_Employer();
    // this.Get_Student_PageLoadData_Dropdowns()

    this.Search_FromDate=new Date();
    this.Search_FromDate = this.New_Date(this.Search_ToDate);
    this.Search_ToDate=new Date();
    this.Search_ToDate = this.New_Date(this.Search_ToDate);


    this.Search_Employer();

     
    // this.myInnerHeight = (window.innerHeight);
    // this.myTotalHeight=this.myInnerHeight - 180;
    // this.myTotalHeight=this.myTotalHeight-40;
    // this.myInnerHeight = this.myInnerHeight - 250;

    this.Entry_View=false;
    this.Status_View=true;
    this.Sub_Status_View=true;
}

New_Date(Date_)
{
    this.date = Date_;
    this.year = this.date.getFullYear();
    this.month = this.date.getMonth() + 1;
    if (this.month < 10)
    {
        this.month = "0" + this.month;
    }
    this.day = this.date.getDate().toString();
    if (Number.parseInt(this.day) < 10)
    {
        this.day = "0" + this.day;
    }
    this.date = this.year + "-" + this.month + "-" + this.day;
    return this.date;
}


Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Job_Posting_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==139)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==139)
        {
            
           debugger

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               
                this.Employer_Edit= this.Permissions.Edit;
                this.Job_Posting_Save= this.Permissions.Save;
                this.Employer_Delete= this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}

Create_New_Job_Posting() 
{
this.Entry_View = true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Clr_Employer();
}
Close_Click()
{
this.Entry_View = false;
this.Status_View=true;
this.Sub_Status_View=true;
this.Job_Data=[];

this.Search_Job_Typeahead("");

this.Clr_Employer();


}
trackByFn(index, item) 
{
return index;
}

Clr_Employer()
{

this.Job_Posting_Save =true;
this.Employer_.Employer_Id=0;
this.Employer_.Employer_Name="";
this.Employer_.Description="";
this.Employer_.Mobile="";
this.Employer_.Contact_Person="";
this.Employer_.Email="";
this.Employer_.Address="";
this.Employer_.Country="";
this.Employer_.Description="";
this.Employer_.Details="";
this.Job_Status_=0;
this.Max_Qualification_=null;
this.Experience_=null;

if (this.Users_Data != null && this.Users_Data != undefined)
this.User_Search = this.Users_Data[0];

this.Job_Posting_.Notes="";
this.Job_Posting_.Mandatory="";
this.Job_Posting_.Location="";
// this.Job_Posting_.Interview_Date = new Date();
// this.Job_Posting_.Interview_Date = this.New_Date(this.Job_Posting_.Interview_Date);
this.Job_Posting_.Interview_Date ="";
this.Job_Posting_.Post_Filling_Date ="";

}
show_Loader()
{

}
hide_Loader()
{

}

Search_Employer()
{
    var dept_id = 0, transfer_dept_id=0


debugger

    this.issLoading=true;
    debugger
this.Job_Posting_Service_.Search_Employer(this.Employer_Name_Search,).subscribe(Rows => {
    debugger
this.Employer_Data=Rows[0];
this.Total_Entries=this.Employer_Data.length;

if(this.Employer_Data.length==0)
{
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
 const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

}
// Search_Employer()
// {
//     var Job_Id_=0;

//     debugger
//     var look_In_Date_Value=0,Usersearch=0,Details_='';
//     if (this.Look_In_Date == true )
//     look_In_Date_Value = 1;

//     if (this.Job_.Job_Posting_Id != undefined && this.Job_.Job_Posting_Id != null)
// Job_Id_ = this.Job_.Job_Posting_Id;
    
// // if (this.Search_JobName=='')
// // Details_=undefined;
// // else
// // Details_=this.Search_JobName;

// if (this.User_Search.User_Details_Id != undefined && this.User_Search.User_Details_Id != null)
// Usersearch = this.User_Search.User_Details_Id;
    

// this.issLoading=true;
// debugger
    
// this.Job_Posting_Service_.Search_Employer(moment(this.Search_FromDate).format('YYYY-MM-DD'),
// moment(this.Search_ToDate).format('YYYY-MM-DD'),look_In_Date_Value,Job_Id_,Usersearch).subscribe(Rows => {
// this.Job_Posting_Data=Rows[0];
// debugger
// this.Total_Entries=this.Job_Posting_Data.length;

// if(this.Job_Posting_Data.length==0)
// {
// const dialogRef = this.dialogBox.open
// ( DialogBox_Component, {panelClass:'Dialogbox-Class'
// ,data:{Message:'No Details Found',Type:"3"}});
// }
// this.issLoading=false;
// },
// Rows => { 
//     this.issLoading=false;
//  const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

// }
Delete_Employer(Employer_Id,index)
{
debugger
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
// this.Search_Class();
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{

this.issLoading=true;
debugger
this.Job_Posting_Service_.Delete_Employer(Employer_Id).subscribe(Delete_status => {
    debugger
    
    
if(Delete_status[0][0].Employer_Id_>0){
this.Employer_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
this.Search_Employer();
}
else if(Number(Delete_status[0][0].Employer_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
 },
 Rows => { 
this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
 });
}
 });
}
// Delete_Employer(Employer_Id,index)
// {
// const dialogRef = this.dialogBox.open
// ( DialogBox_Component, {panelClass:'Dialogbox-Class'
// ,data:{Message:'Do you want to delete ?',Type:"true",Heading:'Confirm'}});
// dialogRef.afterClosed().subscribe(result =>
// {
// if(result=='Yes')
// {
//     this.issLoading=true;
// this.Job_Posting_Service_.Delete_Employer(Employer_Id).subscribe(Delete_status => {
//     debugger
// if(Number(Delete_status[0][0].Employer_Id_)>0){
// this.Employer_Data.splice(this.EditIndex, 1);
// const dialogRef = this.dialogBox.open
// ( DialogBox_Component, {panelClass:'Dialogbox-Class'
// ,data:{Message:'Deleted',Type:"false"}});

// this.Employer_.Employer_Name="";
// this.Search_Job_Typeahead('');
// this.Search_Employer();
// }
// else{
//     const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
// }
// this.issLoading=false;
// },
// Rows => { this.issLoading=false;
//  const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

// }
// });
// }




Add_Document_Click_Employer(){
    // this.clear_Document()
    this.Student_Service_.Get_Employer_Documents(this.Employer_.Employer_Id).subscribe(res=>{
        console.log('res:@@@@@ ', res);
        this.Employer_.uploaded_Document=res[0]
        this.Add_Document_view=true;

    },err=>{
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Error Occured", Type: "2" },
        });
    })
}
















Save_Employer()
{

   
debugger
 

    
 if (this.Employer_.Employer_Name == undefined || this.Employer_.Employer_Name == null|| this.Employer_.Employer_Name == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Employer Name', Type: "3" } });
    return;
}

if (this.Employer_.Description == undefined || this.Employer_.Description == null|| this.Employer_.Description == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter  Description', Type: "3" } });
    return;
}

if (this.Employer_.Mobile == undefined || this.Employer_.Mobile == null|| this.Employer_.Mobile == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Mobile', Type: "3" } });
    return;
}

if (this.Employer_.Email == undefined || this.Employer_.Email == null|| this.Employer_.Email == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter  Email', Type: "3" } });
    return;
}

if (this.Employer_.Address == undefined || this.Employer_.Address == null|| this.Employer_.Address == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Address ', Type: "3" } });
    return;
}


// if (this.Job_Status_ == undefined || this.Job_Status_ == null|| this.Job_Status_ == 0) {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Job Status', Type: "3" } });
//     return;
// }

// if (this.Employer_.Interview_Date == undefined || this.Employer_.Interview_Date == null|| this.Employer_.Interview_Date == "" ||this.Employer_.Interview_Date=="NaN-NaN-NaN") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Choose Interview Date', Type: "3" } });
//     return;
// }


if (this.Employer_.Country == undefined || this.Employer_.Country == null|| this.Employer_.Country == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Country', Type: "3" } });
    return;
}


if (this.Employer_.Details == undefined || this.Employer_.Details == null|| this.Employer_.Details == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Details', Type: "3" } });
    return;
}


if (this.Employer_.Contact_Person == undefined || this.Employer_.Contact_Person == null|| this.Employer_.Contact_Person == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Contact Person', Type: "3" } });
    return;
}






// if (this.Job_Posting_.Mandatory == undefined || this.Job_Posting_.Mandatory == null|| this.Job_Posting_.Mandatory == "") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Mandatory', Type: "3" } });
//     return;
// }



else{

//     debugger
// this.Job_Posting_.Qualification_Id=this.Max_Qualification_.Max_Qualification_Id
// this.Job_Posting_.Qualification_Name=this.Max_Qualification_.Max_Qualification_Name

// this.Job_Posting_.Experience_Id=this.Experience_.Experience_Id
// this.Job_Posting_.Experience_Name=this.Experience_.Experience_Name

// document.getElementById("Save_Button").hidden=true;

this.Job_Posting_Save =false;
this.issLoading=true;
debugger
this.Job_Posting_Service_.Save_Employer(this.Employer_).subscribe(Save_status => {
    debugger
    this.issLoading=false;
Save_status=Save_status[0];
if(Save_status!=undefined)
{
if (Number(Save_status[0].Employer_Id_) > 0) 
{

debugger



  


const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
document.getElementById("Save_Button").hidden=false;

this.Search_Employer();
this.Clr_Employer();

}
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
});

}
}
Edit_Employer(Employer_e:Employer,index)
{
    debugger
debugger
this.Entry_View=true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Employer_=Employer_e;
this.Employer_ = Object.assign({}, Employer_e);







 }




Get_Lead_Load_Data_ByUser(Login_User)
    {
        
        this.issLoading = true;
        this.Student_Service_.Get_Lead_Load_Data_ByUser(Login_User).subscribe(Rows => 
        
    {
     

   this.Users_Data = Rows[0].slice();
   this.Users_Temp.User_Details_Id = 0;
   this.Users_Temp.User_Details_Name = "All";
   this.Users_Data.unshift(Object.assign({},this.Users_Temp));
   this.User_Search = this.Users_Data[0];
   
  
},
Rows => { 
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });
}


Search_Job_Typeahead(event: any) {

    debugger


    var Value = "";
    if (event.target == undefined) Value = "";
    else{
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();

    if (event.target.value == undefined) Value = "";}

if (
    this.Job_Data == undefined ||
    this.Job_Data.length == 0
) {
    this.issLoading = true;
    this.Student_Service_.Search_Job_Typeahead("").subscribe(
        (Rows) => {
            if (Rows != null) {

                debugger
                this.Job_Data = Rows[0];
                this.Job_Data_Filter = []
                for (var i = 0; i < this.Job_Data.length; i++) {
                    if (
                        this.Job_Data[i].Details.toLowerCase().includes(
                            Value
                        )
                    )
                        this.Job_Data_Filter.push(
                            this.Job_Data[i]
                        );
                }
                this.issLoading = false;
            }
        },
        (Rows) => {
            this.issLoading = false;
        }
    );
}else {
    this.Job_Data_Filter = [];
    for (var i = 0; i < this.Job_Data.length; i++) {
        if (
            this.Job_Data[i].Details.toLowerCase().includes(Value)
        )
            this.Job_Data_Filter.push(this.Job_Data[i]);
    }
}
// }
}
display_Job(Job_: Job_Posting) {
if (Job_) {
    return Job_.Details;
}
}





Search_Job_Qualification_Typeahead(event: any) {
    
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Max_Qualification_Data=[]
    if (this.Max_Qualification_Data == undefined || this.Max_Qualification_Data.length == 0) {
        this.issLoading = true;

        this.Max_Qualification_Service_.Search_Job_Qualification_Typeahead(Value).subscribe(
            (Rows) => {
                
                if (Rows != null) {
                    this.Max_Qualification_Data = Rows[0];
                    this.Max_Qualification_Data_Filter = [];
                    for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
                        if (
                            this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value)
                        )
                            this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Max_Qualification_Data_Filter = [];
        for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
            if (this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value))
                this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
        }
    }
}

display_Job_Qualification(Max_Qualification_e: Max_Qualification) 
{
    if (Max_Qualification_e) {
        
        return Max_Qualification_e.Max_Qualification_Name;
    }
}



Search_Experience_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Experience_Data == undefined || this.Experience_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Experience_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Experience_Data = Rows[0];
                    this.Experience_Data_Filter = [];
                    for (var i = 0; i < this.Experience_Data.length; i++) {
                        if (
                            this.Experience_Data[i].Experience_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Experience_Data_Filter.push(this.Experience_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Experience_Data_Filter = [];
        for (var i = 0; i < this.Experience_Data.length; i++) {
            if (
                this.Experience_Data[i].Experience_Name.toLowerCase().includes(Value)
            )
                this.Experience_Data_Filter.push(this.Experience_Data[i]);
        }
    }
}
display_Experience(Experience_e: Experience) {
    if (Experience_e) {
        return Experience_e.Experience_Name;
    }
}


// Get_Student_PageLoadData_Dropdowns() {
//     this.Student_Service_.Get_Student_PageLoadData_Dropdowns().subscribe(
//         (Rows) => {
            
          

//             this.Employer_Data = Rows[24].slice();
//             this.Employer_Temp.Employer_Id = 0;
//             this.Employer_Temp.Employer_Name = "Select";
//             this.Employer_Data.unshift(Object.assign({}, this.Employer_Temp));
//             this.Employer_ = this.Employer_Data[0];


//         },
//         (Rows) => {
//             const dialogRef = this.dialogBox.open(DialogBox_Component, {
//                 panelClass: "Dialogbox-Class",
//                 data: { Message: "Error Occured", Type: "2" },
//             });
//         }
//     );
// }




File_Change_std_Doc(event: Event) {

    this.file_b2b_changed=true
    const file = (event.target as HTMLInputElement).files;
    console.log('file: ', file);
    this.Employer_.Document_file = file;
    this.Employer_.Image_File_Name = file[0].name;
}
Save_User_Document(){
    console.log('	this.file_b2b_changed: ', 	this.file_b2b_changed);
    console.log('this.Employer_: ', this.Employer_);
    if (!this.Employer_.Image_Description) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Description', Type: '3' } });
    } else if (!this.file_b2b_changed &&this.Employer_.Employer_Document_Id  ) {   //for edit if image is there then no need to upload to s3
        this.Save_Employer_Document();
    } else if (!this.Employer_.Document_file.length) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Document', Type: '3' } });
    } else {
        this.upload();
    }
    

}
upload(){
    this.issLoading=true
    console.log('   this.Employer_: ',    this.Employer_);
    
      this.Student_Service_.uploadFile(  this.Employer_.Document_file.item(0)).then(
        res=>{
            console.log('  this.Employer_: ',   this.Employer_);
              this.Employer_.Image_Path =res['key']
            console.log('res: ', res);
            this.Save_Employer_Document()
        }
    )

}
Save_Employer_Document(){
    this.issLoading=true
debugger
    console.log(' this.Employer_: ',  this.Employer_);
    this.Student_Service_.Save_Employer_Document(  this.Employer_).subscribe(Save_status => { 
        debugger
        
        if(Save_status[0][0]['id'])
        console.log('Save_status: ', Save_status);
        this.Student_Service_.Get_Employer_Documents(this.Employer_.Employer_Id).subscribe(res=>{
            console.log('res: ', res);
            this.Employer_.uploaded_Document=res[0]
            this.issLoading=false
            this.file_b2b_changed=false
        this.clear_Document()

        })
    },err=>{
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Error Occured", Type: "2" },
        });
    }) 
}
clear_Document(){
	
	this.Employer_.Employer_Document_Id =0;
	this.Employer_.Document_file = [];
						this.Employer_.Image_File_Name = '';
						this.Employer_.Image_Description = '';
}

Edit_Documents(doc)
{
	this.Employer_.Employer_Document_Id=doc.Employer_Document_Id

	this.Employer_.Image_Description = doc.Image_Description;
	this.Employer_.Image_File_Name = doc.Image_File_Name;
}	


Download_Documents(doc){
		var bs = environment.FilePath;
		var s = bs + doc;
		window.open(s, "_blank");
	}

    Delete_Document(doc_Id){
		this.issLoading=true
		console.log('doc_Id: ', doc_Id);
		this.Student_Service_.Delete_Employer_Documents(doc_Id).subscribe(res=>{
			console.log('res:@@@@@ ', res);
			if(res[0][0]['IsDelete']){
				this.issLoading=false
				this.clear_Document()

				this.Employer_.uploaded_Document=res[1]
				this.Add_Document_view=true;
			}

		},err=>{
			const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
		})

	}
}
