import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Interview_Outcome_ReportComponent } from './Interview_Outcome_Report.component';

describe('Interview_Outcome_ReportComponent', () => {
  let component: Interview_Outcome_ReportComponent;
  let fixture: ComponentFixture<Interview_Outcome_ReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Interview_Outcome_ReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Interview_Outcome_ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
