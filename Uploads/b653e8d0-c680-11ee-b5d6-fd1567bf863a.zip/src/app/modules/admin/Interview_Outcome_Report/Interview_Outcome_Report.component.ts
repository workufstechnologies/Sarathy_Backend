import { Component, OnInit,Input,Injectable, ErrorHandler } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of as observableOf, merge, throwError } from 'rxjs';
import { Job_Posting_Service } from '../../../services/Job_Posting.Service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Job_Posting} from '../../../models/Job_Posting';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogConfig, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS} from '@angular/material';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';
import { getParseErrors, syntaxError } from '@angular/compiler';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component'
//import { ConsoleReporter } from 'jasmine';
import { error } from '@angular/compiler/src/util';
import { Sub_Status } from 'app/models/Sub_Status';
import { Job_Status } from 'app/models/Job_Status';
import { User_Details } from 'app/models/User_Details';
import { Student_Service } from 'app/services/Student.Service';

import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { environment } from 'environments/environment';
import * as io from "socket.io-client";
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { event } from 'jquery';
import { Max_Qualification } from 'app/models/Max_Qualification';
import { Max_Qualification_Service } from 'app/services/Max_Qualification.Service';
import { Experience } from 'app/models/Experience';
import { University_Service } from 'app/services/University.service';
import { Employer } from 'app/models/Employer';
import { Job } from 'app/models/Job';
import { Student_Jobs } from 'app/models/Student_Jobs';
import { Interview_Status } from 'app/models/Level_Detail copy';
import { Interview_Outcome } from 'app/models/Interview_Outcome';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
parse: {
dateInput: 'DD/MM/YYYY',
},
display: {
dateInput: 'DD/MM/YYYY',monthYearLabel: 'MMM YYYY',dateA11yLabel: 'DD/MM/YYYY',monthYearA11yLabel: 'MMMM YYYY',
},
};

@Component({
selector: 'app-Interview_Outcome_Report',
templateUrl: './Interview_Outcome_Report.component.html',
styleUrls: ['./Interview_Outcome_Report.component.css'],
providers: [
    {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
],
})
export class  Interview_Outcome_ReportComponent implements OnInit {

url = environment.NotificationPath; // 'http://regnewapi.trackbox.co.in:3646/'
private socket;

Job_Posting_Data:Job_Posting[]
Job_Posting_:Job_Posting= new Job_Posting();
Job_Posting_Name_Search:string;
Entry_View:boolean=true;
Sub_Status_View:boolean=true;
Status_View:boolean=true;
EditIndex: number;
Menu_Id:number=173;
color = 'primary';
mode = 'indeterminate';
value = 50;Total_Entries:Number;
issLoading: boolean;
Job_Posting_Edit:boolean;
Job_Posting_Save:boolean;
Job_Posting_Delete:boolean;
array:any;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";
Permissions: any;
Job_Posting_Data1:Job_Posting[]

Sub_Status_Data:Sub_Status[]
Sub_Status_:Sub_Status= new Sub_Status();
Sub_Status_Search:string;
Interview_Status_Temp:Interview_Status = new Interview_Status();


Max_Qualification_Data: Max_Qualification[];
	Max_Qualification_Data_Filter: Max_Qualification[];
	Max_Qualification_: Max_Qualification = new Max_Qualification();
	Max_Qualification_Temp_: Max_Qualification = new Max_Qualification();

    Employer_: Employer = new Employer();
    Employer_Search_: Employer = new Employer();
	Employer_Temp: Employer = new Employer();
	Employer_Data: Employer[];


    Job2_Temp_: Job = new Job();
    Job2_Temp1_: Job = new Job();
	Job_Tab_: Job = new Job();


    Student_Jobs_: Student_Jobs = new Student_Jobs();


// Status_Type_:number=0;


// Job_Status_: Job_Status = new Job_Status();
// Job_Status_Temp: Job_Status = new Job_Status();
// Job_Status_Data: Job_Status[];

Job_Status_ :number =0;

Users_Data: User_Details[];
Users_Temp: User_Details = new User_Details();
User_Search: User_Details = new User_Details();

Edit_View:boolean=false;

Search_FromDate: Date = new Date();
Search_ToDate: Date = new Date();
Look_In_Date: Boolean = false;
Search_FromDate_temp: Date = new Date();
Search_ToDate_temp: Date = new Date();
year: any;
month: any;
day: any;

Interest_Status_: number = 0;

Table_View:boolean=true;
User_Details_Temp_: User_Details = new User_Details();
date: any;

Search_JobName:string="";


Interview_Status_:Interview_Status = new Interview_Status();
Job_Data: Job_Posting[];
Job_Data_Filter: Job_Posting[];
Job_Temp: Job_Posting = new Job_Posting();
Job_: Job_Posting = new Job_Posting();

Visa_Status_:number=0;

Experience_Data: Experience[];
	Experience_Data_Filter: Experience[];
	Experience_: Experience = new Experience();
	Experience__Temp_: Experience = new Experience();
    FromDate:Date;
    ToDate:Date;
    Date_value: string;
    Time_Change: number;
	ToDateString:string;
	FromDateString:string;
	TodayString:string;
    Interview_Status_Data: Interview_Status[];
	date_time: number;
    Interview_Outcome_Data: Interview_Outcome[];
    Interview_Outcome_:Interview_Outcome = new Interview_Outcome();

    Job_Users_: User_Details = new User_Details();

    Job_Posting1_: Job_Posting = new Job_Posting();
    Interview_Outcome_Temp:Interview_Outcome = new Interview_Outcome();

constructor(public Student_Service_:Student_Service,public University_Service_: University_Service,public Job_Posting_Service_:Job_Posting_Service,public Max_Qualification_Service_: Max_Qualification_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) {
    this.socket = io(this.url, {
        transports: ["websocket"],
        auth: {
            token: localStorage.getItem("token"),
        },
    });
    this.socket = io(this.url);
} 
ngOnInit() 
{
    debugger
    this.Login_User=localStorage.getItem(("Login_User"));
    // this.Date_value = localStorage.getItem("Look_In_");

    this.FromDate = new Date(localStorage.getItem('Search_FromDate'))
    this.ToDate = new Date(localStorage.getItem('Search_ToDate'));

    this.Time_Change = Number(localStorage.getItem("Time_Change"));
    this.ToDateString = this.ToDate.toString();
    this.FromDateString = this.FromDate.toString();
    this.TodayString = new Date().toString();
    this.date_time = Number(localStorage.getItem("date_time"));

    if (this.ToDateString !== this.TodayString && this.FromDateString !== this.TodayString)
    {
        localStorage.setItem("Time_Change", "0");

    }

    
    // this.array=Get_Page_Permission(this.Menu_Id);
    // if(this.array==undefined || this.array==null)
    // {
    // localStorage.removeItem('token');
    // this.router.navigateByUrl('/auth/login');
    // }
    // else 
    {
    // this.Job_Posting_Edit= this.array.Edit;
    // this.Job_Posting_Save= this.array.Save;
    // this.Job_Posting_Delete= this.array.Delete;
this.Page_Load()
}}
Page_Load()
{debugger
    this.Get_Menu_Status(170,this.Login_User); 
	this.myInnerHeight = window.innerHeight;
    this.myTotalHeight = this.myInnerHeight;
    this.myTotalHeight = this.myTotalHeight - 280;
    this.myInnerHeight = this.myInnerHeight - 210;
    debugger
    
    this.Clr_Job_Posting();
    this.Get_Student_PageLoadData_Dropdowns()

    // this.Search_FromDate=new Date();
    // this.Search_FromDate = this.New_Date(this.Search_ToDate);
    // this.Search_ToDate=new Date();
    // this.Search_ToDate = this.New_Date(this.Search_ToDate);
    this.Get_Lead_Load_Data_ByUser(this.Login_User);
    this.Search_FromDate = this.New_Date(this.Search_FromDate);
    this.Search_ToDate = this.New_Date(this.Search_ToDate);

   

     
    // this.myInnerHeight = (window.innerHeight);
    // this.myTotalHeight=this.myInnerHeight - 180;
    // this.myTotalHeight=this.myTotalHeight-40;
    // this.myInnerHeight = this.myInnerHeight - 250;

    this.Entry_View=false;
    this.Status_View=true;
    this.Sub_Status_View=true;
    this.Look_In_Date=false;
}

New_Date(Date_)
{
    this.date = Date_;
    this.year = this.date.getFullYear();
    this.month = this.date.getMonth() + 1;
    if (this.month < 10)
    {
        this.month = "0" + this.month;
    }
    this.day = this.date.getDate().toString();
    if (Number.parseInt(this.day) < 10)
    {
        this.day = "0" + this.day;
    }
    this.date = this.year + "-" + this.month + "-" + this.day;
    return this.date;
}


Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Job_Posting_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==173)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Interview_Report');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==173)
        {
            
           debugger

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Interview_Report');
                }
               
                this.Job_Posting_Edit= this.Permissions.Edit;
                this.Job_Posting_Save= this.Permissions.Save;
                this.Job_Posting_Delete= this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}

Create_New_Job_Posting() 
{
this.Entry_View = true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Clr_Job_Posting();
}
Close_Click()
{
this.Entry_View = false;
this.Status_View=true;
this.Sub_Status_View=true;
this.Job_Data=[];

this.Search_Job_Typeahead("");

this.Clr_Job_Posting();


}
trackByFn(index, item) 
{
return index;
}

Clr_Job_Posting()
{

this.Job_Posting_Save =true;
this.Job_Posting_.Job_Posting_Id=0;
this.Job_Posting_.Details="";
this.Job_Posting_.Description="";
this.Job_Posting_.By_User=0;
this.Job_Posting_.Job_Status="";
this.Job_Posting_.Available_Vacancy="";
this.Job_Posting_.No_of_Positions="";
this.Job_Posting_.Salary="";
this.Job_Status_=0;
this.Max_Qualification_=null;
this.Experience_=null;

if (this.Users_Data != null && this.Users_Data != undefined)
this.User_Search = this.Users_Data[0];

if (this.Employer_Data != null && this.Employer_Data != undefined)
this.Employer_ = this.Employer_Data[0];

this.Job_Posting_.Notes="";
this.Job_Posting_.Mandatory="";
this.Job_Posting_.Location="";
// this.Job_Posting_.Interview_Date = new Date();
// this.Job_Posting_.Interview_Date = this.New_Date(this.Job_Posting_.Interview_Date);
this.Job_Posting_.Interview_Date ="";
this.Job_Posting_.Post_Filling_Date ="";

}
show_Loader()
{

}
hide_Loader()
{

}
Search_Job_Posting_Report()
{
    var Job_Id_=0,Interview_Outcome_Id_=0;

    debugger
    var look_In_Date_Value=0,Usersearch=0,Details_='',employer_id=0;
    if (this.Look_In_Date == true )
    look_In_Date_Value = 1;

    if (this.Job_.Job_Posting_Id != undefined && this.Job_.Job_Posting_Id != null)
Job_Id_ = this.Job_.Job_Posting_Id;

if (this.Interview_Outcome_ != undefined && this.Interview_Outcome_ != null)
    if (this.Interview_Outcome_.Interview_Outcome_Id != undefined && this.Interview_Outcome_.Interview_Outcome_Id != null)
    Interview_Outcome_Id_ = this.Interview_Outcome_.Interview_Outcome_Id;
// if (this.Visa_Status_ != undefined && this.Visa_Status_ != null)
// visa_status_ = this.Visa_Status_;
    
// if (this.Search_JobName=='')
// Details_=undefined;
// else
// Details_=this.Search_JobName;

// if (this.User_Search.User_Details_Id != undefined && this.User_Search.User_Details_Id != null)
// Usersearch = this.User_Search.User_Details_Id;

// if (this.Employer_Search_.Employer_Id != undefined && this.Employer_Search_.Employer_Id  != null)
// employer_id = this.Employer_Search_.Employer_Id ;
    

this.issLoading=true;
debugger
    
this.Job_Posting_Service_.Search_Interview_Outcome_Report(moment(this.Search_FromDate).format('YYYY-MM-DD'),
moment(this.Search_ToDate).format('YYYY-MM-DD'),look_In_Date_Value,Interview_Outcome_Id_).subscribe(Rows => {
this.Job_Posting_Data=Rows[0];
debugger
this.Total_Entries=this.Job_Posting_Data.length;

if(this.Job_Posting_Data.length==0)
{
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
 const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

}

Delete_Job_Posting(Job_Posting_Id,index)
{
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'Do you want to delete ?',Type:"true",Heading:'Confirm'}});
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
    this.issLoading=true;
this.Job_Posting_Service_.Delete_Job_Posting(Job_Posting_Id).subscribe(Delete_status => {
    debugger
if(Number(Delete_status[0][0].Job_Posting_Id_)>0){
this.Job_Posting_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'Deleted',Type:"false"}});

this.Job_.Details="";
this.Search_Job_Typeahead('');
this.Search_Job_Posting_Report();
}
else if(Number(Delete_status[0][0].Job_Posting_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Cannot Delete!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
},
Rows => { this.issLoading=false;
 const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

}
});
}
Save_Job_Posting()
{

    if(this.Job_Status_==1){ this.Job_Posting_.Job_Status="Active"};
    if(this.Job_Status_==2){ this.Job_Posting_.Job_Status="Inactive"}
debugger
    if(this.Job_Posting_.Interview_Date!=null || this.Job_Posting_.Interview_Date!=""||this.Job_Posting_.Interview_Date!=undefined )
    { this.Job_Posting_.Interview_Date = this.New_Date(new Date(moment(this.Job_Posting_.Interview_Date).format("YYYY-MM-DD")));}

    if(this.Job_Posting_.Interview_Date==null || this.Job_Posting_.Interview_Date==""||this.Job_Posting_.Interview_Date==undefined|| this.Job_Posting_.Interview_Date=="NaN-NaN-NaN" )
    { this.Job_Posting_.Interview_Date = ""}



    if(this.Job_Posting_.Post_Filling_Date!=null || this.Job_Posting_.Post_Filling_Date!=""||this.Job_Posting_.Post_Filling_Date!=undefined )
    { this.Job_Posting_.Post_Filling_Date = this.New_Date(new Date(moment(this.Job_Posting_.Post_Filling_Date).format("YYYY-MM-DD")));}

    if(this.Job_Posting_.Post_Filling_Date==null || this.Job_Posting_.Post_Filling_Date==""||this.Job_Posting_.Post_Filling_Date==undefined|| this.Job_Posting_.Post_Filling_Date=="NaN-NaN-NaN" )
    { this.Job_Posting_.Post_Filling_Date = ""}




  debugger
    this.Job_Posting_.By_User=Number(this.Login_User);

 if (this.Job_Posting_.Details == undefined || this.Job_Posting_.Details == null|| this.Job_Posting_.Details == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Job', Type: "3" } });
    return;
}

if (this.Job_Posting_.Description == undefined || this.Job_Posting_.Description == null|| this.Job_Posting_.Description == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Job Description', Type: "3" } });
    return;
}

if (this.Job_Posting_.Available_Vacancy == undefined || this.Job_Posting_.Available_Vacancy == null|| this.Job_Posting_.Available_Vacancy == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Available Vacancy', Type: "3" } });
    return;
}

if (this.Job_Posting_.No_of_Positions == undefined || this.Job_Posting_.No_of_Positions == null|| this.Job_Posting_.No_of_Positions == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter No of Positions', Type: "3" } });
    return;
}

if (this.Job_Posting_.Salary == undefined || this.Job_Posting_.Salary == null|| this.Job_Posting_.Salary == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Salary ', Type: "3" } });
    return;
}


if (this.Job_Status_ == undefined || this.Job_Status_ == null|| this.Job_Status_ == 0) {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Job Status', Type: "3" } });
    return;
}

// if (this.Job_Posting_.Interview_Date == undefined || this.Job_Posting_.Interview_Date == null|| this.Job_Posting_.Interview_Date == "" ||this.Job_Posting_.Interview_Date=="NaN-NaN-NaN") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Choose Interview Date', Type: "3" } });
//     return;
// }


if (this.Job_Posting_.Location == undefined || this.Job_Posting_.Location == null|| this.Job_Posting_.Location == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Location', Type: "3" } });
    return;
}


if (this.Job_Posting_.Notes == undefined || this.Job_Posting_.Notes == null|| this.Job_Posting_.Notes == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Notes', Type: "3" } });
    return;
}


if (
    this.Employer_ == undefined ||
    this.Employer_ == null ||
    this.Employer_.Employer_Id == undefined ||
    this.Employer_.Employer_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Employer", Type: "3" },
    });
    return;
}


if (
    this.Max_Qualification_ == undefined ||
    this.Max_Qualification_ == null ||
    this.Max_Qualification_.Max_Qualification_Id == undefined ||
    this.Max_Qualification_.Max_Qualification_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Qualification", Type: "3" },
    });
    return;
}


if (
    this.Experience_ == undefined ||
    this.Experience_ == null ||
    this.Experience_.Experience_Id == undefined ||
    this.Experience_.Experience_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Experience", Type: "3" },
    });
    return;
}



// if (this.Job_Posting_.Mandatory == undefined || this.Job_Posting_.Mandatory == null|| this.Job_Posting_.Mandatory == "") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Mandatory', Type: "3" } });
//     return;
// }



else{

    debugger
this.Job_Posting_.Qualification_Id=this.Max_Qualification_.Max_Qualification_Id
this.Job_Posting_.Qualification_Name=this.Max_Qualification_.Max_Qualification_Name

this.Job_Posting_.Experience_Id=this.Experience_.Experience_Id
this.Job_Posting_.Experience_Name=this.Experience_.Experience_Name

this.Job_Posting_.Employer_Id=this.Employer_.Employer_Id
this.Job_Posting_.Employer_Name=this.Employer_.Employer_Name

// document.getElementById("Save_Button").hidden=true;

this.Job_Posting_Save =false;
this.issLoading=true;
debugger
this.Job_Posting_Service_.Save_Job_Posting(this.Job_Posting_).subscribe(Save_status => {
    debugger
    this.issLoading=false;
Save_status=Save_status[0];
if(Save_status!=undefined)
{
if (Number(Save_status[0].Job_Posting_Id_) > 0) 
{

debugger



    {

         if ( Save_status[0].Notification_Id_>0 ) {
            // if(Save_status[0].By_User_!=this.Login_User){
            var message = {
                 
                Student_Name: '',
                From_User_Name: Save_status[0].By_User_Name_,
                Notification_Type_Name: Save_status[0].Notification_Type_Name_,
                Entry_Type: Save_status[0].Entry_Type_,
                To_User: 0,
                Notification_Id: Save_status[0].Notification_Id_,
                Student_Id: 0,
                By_User:Save_status[0].By_User_,

            };
            this.socket.emit("new-message", message);
            // }
        }
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
  

    }



const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
document.getElementById("Save_Button").hidden=false;

this.Search_Job_Posting_Report();
this.Clr_Job_Posting();

}
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
});

}
}
Edit_Job_Posting(Job_Posting_e:Job_Posting,index)
{
debugger
this.Entry_View=true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Job_Posting_=Job_Posting_e;
this.Job_Posting_ = Object.assign({}, Job_Posting_e);

if(this.Job_Posting_.Job_Status=="Active"){this.Job_Status_ =1}
if(this.Job_Posting_.Job_Status=="Inactive"){this.Job_Status_ =2}
if(this.Job_Posting_.Job_Status=="Select"){this.Job_Status_ =0}

this.Job_Posting_.Interview_Date = this.New_Date(
new Date(moment(this.Job_Posting_.Interview_Date_s).format("YYYY-MM-DD")));

this.Job_Posting_.Post_Filling_Date = this.New_Date(
    new Date(moment(this.Job_Posting_.Post_Filling_Date_s).format("YYYY-MM-DD")));

    this.Max_Qualification_Temp_.Max_Qualification_Id = this.Job_Posting_.Qualification_Id;
    this.Max_Qualification_Temp_.Max_Qualification_Name = this.Job_Posting_.Qualification_Name;
    this.Max_Qualification_ = Object.assign({}, this.Max_Qualification_Temp_);

    this.Experience__Temp_.Experience_Id = this.Job_Posting_.Experience_Id;
    this.Experience__Temp_.Experience_Name = this.Job_Posting_.Experience_Name;
    this.Experience_ = Object.assign({}, this.Experience__Temp_);


    for (var i = 0; i < this.Employer_Data.length; i++) {
        if (
            this.Job_Posting_.Employer_Id ==
            this.Employer_Data[i].Employer_Id
        )
            this.Employer_ = this.Employer_Data[i];
    }


 }




Get_Lead_Load_Data_ByUser(Login_User)
    {
        debugger
        this.issLoading = true;
        this.Student_Service_.Get_Lead_Load_Data_ByUser(Login_User).subscribe(Rows => 
            
    {
        debugger

   this.Users_Data = Rows[0].slice();
   this.Users_Temp.User_Details_Id = 0;
   this.Users_Temp.User_Details_Name = "All";
   this.Users_Data.unshift(Object.assign({},this.Users_Temp));
   this.User_Search = this.Users_Data[0];

  


},
Rows => { 
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });
if(this.Date_value=="false")
				{
				  this.Look_In_Date=false
				
				}
				
			
				if(this.Date_value=="true")
				{
					this.Look_In_Date=true;
					localStorage.setItem("Look_In_", "false");
			
				}
			

			
			if(this.Time_Change > 0)
			 {
				 this.Search_FromDate =this.FromDate;
				 this.Search_ToDate = this.ToDate;
			 }
             this.Search_Job_Posting_Report();
}


Search_Job_Typeahead(event: any) {

    debugger


    var Value = "";
    if (event.target == undefined) Value = "";
    else{
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();

    if (event.target.value == undefined) Value = "";}

if (
    this.Job_Data == undefined ||
    this.Job_Data.length == 0
) {
    this.issLoading = true;
    this.Student_Service_.Search_Job_Typeahead("").subscribe(
        (Rows) => {
            if (Rows != null) {

                debugger
                this.Job_Data = Rows[0];
                this.Job_Data_Filter = []
                for (var i = 0; i < this.Job_Data.length; i++) {
                    if (
                        this.Job_Data[i].Details.toLowerCase().includes(
                            Value
                        )
                    )
                        this.Job_Data_Filter.push(
                            this.Job_Data[i]
                        );
                }
                this.issLoading = false;
            }
        },
        (Rows) => {
            this.issLoading = false;
        }
    );
}else {
    this.Job_Data_Filter = [];
    for (var i = 0; i < this.Job_Data.length; i++) {
        if (
            this.Job_Data[i].Details.toLowerCase().includes(Value)
        )
            this.Job_Data_Filter.push(this.Job_Data[i]);
    }
}
// }
}
display_Job(Job_: Job_Posting) {
if (Job_) {
    return Job_.Details;
}
}





Search_Job_Qualification_Typeahead(event: any) {
    
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Max_Qualification_Data=[]
    if (this.Max_Qualification_Data == undefined || this.Max_Qualification_Data.length == 0) {
        this.issLoading = true;

        this.Max_Qualification_Service_.Search_Job_Qualification_Typeahead(Value).subscribe(
            (Rows) => {
                
                if (Rows != null) {
                    this.Max_Qualification_Data = Rows[0];
                    this.Max_Qualification_Data_Filter = [];
                    for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
                        if (
                            this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value)
                        )
                            this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Max_Qualification_Data_Filter = [];
        for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
            if (this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value))
                this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
        }
    }
}

display_Job_Qualification(Max_Qualification_e: Max_Qualification) 
{
    if (Max_Qualification_e) {
        
        return Max_Qualification_e.Max_Qualification_Name;
    }
}



Search_Experience_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Experience_Data == undefined || this.Experience_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Experience_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Experience_Data = Rows[0];
                    this.Experience_Data_Filter = [];
                    for (var i = 0; i < this.Experience_Data.length; i++) {
                        if (
                            this.Experience_Data[i].Experience_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Experience_Data_Filter.push(this.Experience_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Experience_Data_Filter = [];
        for (var i = 0; i < this.Experience_Data.length; i++) {
            if (
                this.Experience_Data[i].Experience_Name.toLowerCase().includes(Value)
            )
                this.Experience_Data_Filter.push(this.Experience_Data[i]);
        }
    }
}
display_Experience(Experience_e: Experience) {
    if (Experience_e) {
        return Experience_e.Experience_Name;
    }
}


Get_Student_PageLoadData_Dropdowns() {
    debugger
    this.Student_Service_.Get_Student_PageLoadData_Dropdowns().subscribe(
        (Rows) => {
            debugger 
            this.Interview_Status_Data = Rows[28].slice();
            this.Interview_Status_Temp.Interview_Status_Id = 0;
            this.Interview_Status_Temp.Interview_Status_Name = "Select";
            this.Interview_Status_Data.unshift(Object.assign({}, this.Interview_Status_Temp));
            this.Interview_Status_ = this.Interview_Status_Data[0];

            this.Employer_Data = Rows[24].slice();
            this.Employer_Temp.Employer_Id = 0;
            this.Employer_Temp.Employer_Name = "Select";
            this.Employer_Data.unshift(Object.assign({}, this.Employer_Temp));
            this.Employer_ = this.Employer_Data[0];
            this.Employer_Search_ =this.Employer_Data[0];

            this.Interview_Outcome_Data = Rows[29].slice();
            this.Interview_Outcome_Temp.Interview_Outcome_Id = 0;
            this.Interview_Outcome_Temp.Interview_Outcome_Name = "Select";
            this.Interview_Outcome_Data.unshift(Object.assign({}, this.Interview_Outcome_Temp));
            this.Interview_Outcome_ = this.Interview_Outcome_Data[0];
        },
        (Rows) => {
            const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
        }
    );
}


Edit_Job(Student_Job_temp: Student_Jobs, index) {
    //
    debugger
    this.Student_Jobs_ = Object.assign({}, Student_Job_temp);
    // this.edit_job_index = 1;

    this.Edit_View=true;
this.Table_View=false;
    for (var i = 0; i < this.Job_Posting_Data.length; i++) {
        if (this.Student_Jobs_.Job_Name == this.Job_Posting_Data[i].Job_Name)
            this.Job_Posting1_ = this.Job_Posting_Data[i];
    }

    this.Job2_Temp_.Job_Posting_Id = this.Job_Posting_.Job_Posting_Id;
    this.Job2_Temp_.Job_Name = this.Job_Posting_.Job_Name;
    this.Job2_Temp_.Employer_Id = Student_Job_temp.Employer_Id;
    this.Job2_Temp_.Employer_Name = Student_Job_temp.Employer_Name;
    this.Job2_Temp_.Job_Id = Student_Job_temp.Job_Id;
    this.Job_Tab_ = Object.assign({}, this.Job2_Temp_);

    // this.Job2_Temp1_.Employer_Id = this.Job_Posting_.Employer_Id;
    // this.Job2_Temp1_.Employer_Name = this.Job_Posting_.Employer_Name;
    // this.Job_Tab_ = Object.assign({}, this.Job2_Temp1_);
    
    // this.Employer1_Temp_.Employer_Id = Student_Job_temp.Employer_Id;
    // this.Employer1_Temp_.Employer_Name = Student_Job_temp.Employer_Name;
    // this.Job_Tab_ = Object.assign({}, this.Employer1_Temp_);


    this.User_Details_Temp_.User_Details_Id = Student_Job_temp.Job_User_Id;
    this.User_Details_Temp_.User_Details_Name = Student_Job_temp.Job_User_Name;
    this.Job_Users_ = Object.assign({}, this.User_Details_Temp_);

    this.Visa_Status_=Student_Job_temp.Visa_Status;
    this.Interest_Status_ = this.Student_Jobs_.Interest_Status;
    debugger
    for (var ii = 0; ii < this.Interview_Status_Data.length; ii++) {
        if (this.Student_Jobs_.Interview_Status == this.Interview_Status_Data[ii].Interview_Status_Id)
            this.Interview_Status_ = this.Interview_Status_Data[ii];
    }



    this.Student_Jobs_.Interview_Date = this.New_Date(
        new Date(moment(this.Student_Jobs_.Interview_Date).format("YYYY-MM-DD")));

    // this.Get_Student_Job(this.Student_Jobs_.Student_Id);
}


Save_Student_Job() {
    debugger
    this.Student_Jobs_.User_Id = Number(this.Login_User);
    // this.Student_Jobs_.Student_Id = this.Job_Posting_.Student_Id;
    this.Student_Jobs_.Job_Id = this.Job_Tab_.Job_Id;		//  this.Student_Jobs_.Job_Id = this.Job_Tab_.Job_Id;
    this.Student_Jobs_.Job_Name = this.Job_Tab_.Job_Name;
    this.Student_Jobs_.Employer_Id = this.Job_Tab_.Employer_Id;
    this.Student_Jobs_.Employer_Name = this.Job_Tab_.Employer_Name;

    this.Student_Jobs_.Job_User_Id = this.Job_Users_.User_Details_Id;
    this.Student_Jobs_.Job_User_Name = this.Job_Users_.User_Details_Name;

    this.Student_Jobs_.Interview_Status = this.Interview_Status_.Interview_Status_Id;
    this.Student_Jobs_.Interview_Status_Name = this.Interview_Status_.Interview_Status_Name; // Include the name
    this.Student_Jobs_.Interest_Status = this.Interest_Status_;
    this.Student_Jobs_.Visa_Status = 2;
    this.Student_Jobs_.Interview_Scheduled = 1;

    if(this.Student_Jobs_.Interview_Date!=null || this.Student_Jobs_.Interview_Date!=""||this.Student_Jobs_.Interview_Date!=undefined )
    { this.Student_Jobs_.Interview_Date = this.New_Date(new Date(moment(this.Student_Jobs_.Interview_Date).format("YYYY-MM-DD")));}

    if(this.Student_Jobs_.Interview_Date==null || this.Student_Jobs_.Interview_Date==""||this.Student_Jobs_.Interview_Date==undefined|| this.Student_Jobs_.Interview_Date=="NaN-NaN-NaN" )
    { this.Student_Jobs_.Interview_Date = ""}

    if (
        this.Job_Tab_ == undefined ||
        this.Job_Tab_ == null ||
        this.Job_Tab_.Employer_Id == 0
    ) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Select Job ", Type: "3" },
        });
        return;
    }

    // if (
    //     this.Job_Users_ == undefined ||
    //     this.Job_Users_ == null ||
    //     this.Job_Users_.User_Details_Id == 0
    // ) {
    //     const dialogRef = this.dialogBox.open(DialogBox_Component, {
    //         panelClass: "Dialogbox-Class",
    //         data: { Message: "Select User ", Type: "3" },
    //     });
    //     return;
    // }



    // if (
    // 	this.Interview_Status_ == undefined ||
    // 	this.Interview_Status_ == null ||
    // 	this.Interview_Status_.Interview_Status_Id == 0
    // ) {
    // 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
    // 		panelClass: "Dialogbox-Class",
    // 		data: { Message: "Select Mode of Interview ", Type: "3" },
    // 	});
    // 	return;
    // }

    // if (
    //     this.Student_Jobs_.Interest_Status == undefined ||
    //     this.Student_Jobs_.Interest_Status == null ||
    //     this.Student_Jobs_.Interest_Status == 0
    // ) {
    //     const dialogRef = this.dialogBox.open(DialogBox_Component, {
    //         panelClass: "Dialogbox-Class",
    //         data: { Message: "Select Job Status ", Type: "3" },
    //     });
    //     return;
    // } 
    

    if (
    	this.Student_Jobs_.Visa_Status == undefined ||
    	this.Student_Jobs_.Visa_Status == null ||
    	this.Student_Jobs_.Visa_Status == 0
    ) {
    	const dialogRef = this.dialogBox.open(DialogBox_Component, {
    		panelClass: "Dialogbox-Class",
    		data: { Message: "Select Visa Status ", Type: "3" },
    	});
    	return;
    } 


    // if (
    // 	this.Student_Jobs_.Interview_Date == undefined ||
    // 	this.Student_Jobs_.Interview_Date== null ||
    // 	this.Student_Jobs_.Interview_Date == ''
    // ) {
    // 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
    // 		panelClass: "Dialogbox-Class",
    // 		data: { Message: "Choose Interview Date ", Type: "3" },
    // 	});
    // 	return;
    // } 
    

    // if (
    // 	this.Student_Jobs_.Interview_Time == undefined ||
    // 	this.Student_Jobs_.Interview_Time== null ||
    // 	this.Student_Jobs_.Interview_Time == ''
    // ) {
    // 	const dialogRef = this.dialogBox.open(DialogBox_Component, {
    // 		panelClass: "Dialogbox-Class",
    // 		data: { Message: "Enter Interview Time ", Type: "3" },
    // 	});
    // 	return;
    // } 
    
    
    
    else {
        // document.getElementById("Save_Button").hidden=true;

        // this.Job_Tab_Save=false;
        this.issLoading = true;
        debugger
        this.Student_Service_.Save_Student_Job(this.Student_Jobs_).subscribe(
            (Save_status) => {
                debugger
                this.issLoading = false;
                Save_status = Save_status[0];
                if (Save_status != undefined) {
                    if (Number(Save_status[0].Student_Jobs_Id_) > 0) {
                        const dialogRef = this.dialogBox.open(DialogBox_Component, {
                            panelClass: "Dialogbox-Class",
                            data: { Message: "Saved", Type: "false" },
                        });
                        // document.getElementById("Save_Button").hidden=false;
                        //  this.Get_Student_Job(this.Student_Jobs_.Student_Id);
                        //  this.Search_Registration_Report(this.User_Search.User_Details_Id);
                        this.Get_Lead_Load_Data_ByUser(this.Login_User);
                         this.Clr_Job();
                    }
                } else {
                    const dialogRef = this.dialogBox.open(DialogBox_Component, {
                        panelClass: "Dialogbox-Class",
                        data: { Message: "Error Occured", Type: "2" },
                    });
                    document.getElementById("Save_Button").hidden = false;
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
                const dialogRef = this.dialogBox.open(DialogBox_Component, {
                    panelClass: "Dialogbox-Class",
                    data: { Message: "Error Occured", Type: "2" },
                });
                document.getElementById("Save_Button").hidden = false;
            }
        );
    }
}

Clr_Job()

{

    this.Edit_View=false;
this.Table_View=true;


}








}
