import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Meeting_FollowupComponent } from './Meeting_Followup.component';

describe('Tomorrows_followupComponent', () => {
  let component: Meeting_FollowupComponent;
  let fixture: ComponentFixture<Meeting_FollowupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Meeting_FollowupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Meeting_FollowupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
