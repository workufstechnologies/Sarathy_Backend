import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Employer_DashboardComponent } from './Employer_Dashboard.component';
describe('Home_PageComponent', () => {
let component: Employer_DashboardComponent;
let fixture: ComponentFixture<Employer_DashboardComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Employer_DashboardComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Employer_DashboardComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

