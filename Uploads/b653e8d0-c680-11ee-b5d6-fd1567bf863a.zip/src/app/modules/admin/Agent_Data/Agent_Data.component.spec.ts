import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Agent_DataComponent } from './Agent_Data.component';
describe('Agent_DataComponent', () => {
let component: Agent_DataComponent;
let fixture: ComponentFixture<Agent_DataComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Agent_DataComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Agent_DataComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

