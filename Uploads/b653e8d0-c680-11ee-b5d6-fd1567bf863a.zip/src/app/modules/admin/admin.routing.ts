/***
 * All routes with in admin module should be defined here
 */
 import { Routes } from '@angular/router';
 import { User_DetailsComponent } from './User_Details/User_Details.component';
 import { CountryComponent } from './Country/Country.component'; 
 import { CourseComponent } from './Course/Course.component'; 
 import { Course_IntakeComponent } from './Course_Intake/Course_Intake.component'; 
 import { DocumentComponent } from './Document/Document.component'; 
 import { DurationComponent } from './Duration/Duration.component'; 
 import { IntakeComponent } from './Intake/Intake.component'; 
 import { InternshipComponent } from './Internship/Internship.component'; 
 import { Level_DetailComponent } from './Level_Detail/Level_Detail.component'; 
 import { StudentComponent } from './Student/Student.component'; 
 import { Student_DocumentComponent } from './Student_Document/Student_Document.component'; 
 import { Student_MessageComponent } from './Student_Message/Student_Message.component'; 
 import { Student_StatusComponent } from './Student_Status/Student_Status.component';
 
 import { SubjectComponent } from './Subject/Subject.component'; 
 import { UniversityComponent } from './University/University.component'; 
 import { AdminComponent } from './admin.component';
  import { AgentComponent } from './Agent/Agent.component';
  import { Home_PageComponent } from './Home_Page/Home_Page.component';
  import { DashboardComponent } from './Dashboard/Dashboard.component';
 import { Course_ImportComponent } from './Course_Import/Course_Import.component';
 import { Account_GroupComponent } from './Account_Group/Account_Group.component';
 import { Client_AccountsComponent } from './Client_Accounts/Client_Accounts.component';
 import { DepartmentComponent } from './Department/Department.component';
 import { Department_StatusComponent } from './Department_Status/Department_Status.component';
 import { Student_ReportComponent } from './Student_Report/Student_Report.component';
 import { Work_reportComponent } from './Work_report/Work_report.component';
 import { BranchComponent } from './Branch/Branch.component';
 import { RemarksComponent } from './Remarks/Remarks.component';
 import { Enquiry_SourceComponent } from './Enquiry_Source/Enquiry_Source.component';
 import { TimeTrackComponent } from './TimeTrack/TimeTrack.component';
 import { Registration_ReportComponent } from './Registration_Report/Registration_Report.component';
 import { Efficiency_ReportComponent } from './Efficiency_Report/Efficiency_Report.component';
 import { Student_ImportComponent } from './Student_Import/Student_Import.component';
 import { Pending_FollowUpComponent } from './Pending_FollowUp/Pending_FollowUp.component';
 import { FeesComponent } from './Fees/Fees.component';
 import { Fees_Receipt_ReportComponent } from './Fees_Receipt_Report/Fees_Receipt_Report.component';
 import { Enquiry_Source_SummaryComponent } from './Enquiry_Source_Summary/Enquiry_Source_Summary.component';
 import { Counselor_Fees_Receipt_ReportComponent } from './Counselor_Fees_Receipt_Report/Counselor_Fees_Receipt_Report.component';
 import { Counselor_Registration_ReportComponent } from './Counselor_Registration_Report/Counselor_Registration_Report.component';
 import { Student_Summary_ReportComponent } from './Student_Summary_Report/Student_Summary_Report.component';
 import { Staff_Target_ReportComponent } from './Staff_Target_Report/Staff_Target_Report.component';
 import { Student_SearchComponent } from './Student_Search/Student_Search.component';
 import { Work_SummaryComponent } from './Work_Summary/Work_Summary.component';
 import { Userwise_SummaryComponent } from './Userwise_Summary/Userwise_Summary.component';
 import { Branchwise_SummaryComponent } from './Branchwise_Summary/Branchwise_Summary.component';
 import { PageAComponent } from './PageA/PageA.component';
 import { PageCComponent } from './PageC/PageC.component';
 import { PageBComponent } from './PageB/PageB.component';
 import { Enquiry_Source_ReportComponent } from './Enquiry_Source_Report/Enquiry_Source_Report.component';
 import { Receipt_Summary_ReportComponent } from './Receipt_Summary_Report/Receipt_Summary_Report.component';
 import { Registration_SummaryComponent } from './Registration_Summary/Registration_Summary.component';
 import { Enquiry_ConversionComponent } from './Enquiry_Conversion/Enquiry_Conversion.component';
 import { Employee_SummaryComponent } from './Employee_Summary/Employee_Summary.component';
 import { User_RoleComponent } from './User_Role/User_Role.component';
 import { CompanyComponent } from './Company/Company.component';
 import { SettingsComponent } from './Settings/Settings.component';
import { Documentation_ReportComponent } from './Documentation_Report/Documentation_Report.component';
import { Work_HistoryComponent } from './Work_History/Work_History.component';

import { Details_checkComponent } from './Details_check/Details_check.component';
import { Registration_EnquirySourceComponent } from './Registration_EnquirySource/Registration_EnquirySource.component';
import { Check_ListComponent } from './Check_List/Check_List.component';
import {Agent_DetailsComponent} from './Agent_Details/Agent_Details.component';
import { Application_ReportComponent } from './Application_Report/Application_Report.component';
import { TaskComponent } from './Task/Task.component';
import { NotificationComponent } from './Notification/Notification.component';
import { Receipt_ConfirmationComponent } from './Receipt_Confirmation/Receipt_Confirmation.component';
import { Refund_ConfirmationComponent } from './Refund_Confirmation/Refund_Confirmation.component';
import { Refund_ApprovalComponent } from './Refund_Approval/Refund_Approval.component';
import { Student_TaskComponent } from './Student_Task/Student_Task.component';
import { Application_DashboardComponent } from './Application_Dashboard/Application_Dashboard.component';
import { Passport_Expiry_ReportComponent } from './Passport_Expiry_Report/Passport_Expiry_Report.component';
import { Application_StatusComponent } from './Application_Status/Application_Status.component';
import { Task_ItemComponent } from './Task_Item/Task_Item.component';
import { Bph_ReportComponent } from './Bph_Report/Bph_Report.component';
import { Application_ListComponent } from './Application_List/Application_List.component';
import { Application_SettingsComponent } from './Application_Settings/Application_Settings.component';
import { DocumentNameComponent } from './DocumentName/DocumentName.component';
import { AccountsComponent } from './Accounts/Accounts.component';
import { Data_MigrationComponent } from './Data_Migration/Data_Migration.component';
import { Fees_Pending_ReportComponent } from './Fees_Pending_Report/Fees_Pending_Report.component';
import { Class_SummaryComponent } from './Class_Summary/Class_Summary.component';
import { ClassComponent } from './Class/Class.component';
import { Enquirywise_Status_ReportComponent } from './Enquirywise_Status_Report/Enquirywise_Status_Report.component';
import { Department_Status_ReportComponent } from './Department_Status_Report/Department_Status_Report.component';
import { FollowUp_Status_ReportComponent } from './FollowUp_Status_Report/FollowUp_Status_Report.component';
import { Department_ReportComponent } from './Department_Report/Department_Report.component';
import { Attendance_ReportComponent } from './Attendance_Report/Attendance_Report.component';
import { ReferenceComponent } from './Reference/Reference.component';
import { Student_Task_Followup_ReportComponent } from './Student_Task_Followup_Report/Student_Task_Followup_Report.component';
import { TagComponent } from './Tag/Tag.component';
import { Tag_CategoryComponent } from './Tag_Category/Tag_Category.component';
import { Max_Qualification } from 'app/models/Max_Qualification';
import { Max_QualificationComponent } from './Max_Qualification/Max_Qualification.component';
import { LevelComponent } from './Level/Level.component';
import { Job_PostingComponent } from './Job_Posting/Job_Posting.component';
import { Agent_DataComponent } from './Agent_Data/Agent_Data.component';
import { Job_CategoryComponent } from './Job_Category/Job_Category.component';
import { JobComponent } from './Job/Job.component';
import { Pending_Fees_ReportComponent } from './Pending_Fees_Report/Pending_Fees_Report.component';
import { Enquiry_reportComponent } from './Enquiry_report/Enquiry_report.component';
import { Chat_WindowComponent } from './Chat_Window/Chat_Window.component';
import { B2B_AgenciesComponent } from './B2B_Agencies/B2B_Agencies.component';
import { Work_Details_ReportComponent } from './Work_Details_Report/Work_Details_Report.component';
import { EmployerComponent } from './Employer/Employer.component';
import { Job_SummaryComponent } from './Job_Summary/Job_Summary.component';
import { Interview_ReportComponent } from './Interview_Report/Interview_Report.component';
import { Pending_Task_ReportComponent } from './Pending_Task_Report/Pending_Task_Report.component';
import { Employer_DetailsComponent } from './Employer_Details/Employer_Details.component';
import { Tomorrows_followupComponent } from './Tomorrows_followup/Tomorrows_followup.component';
import { Employer_DashboardComponent } from './Employer_Dashboard/Employer_Dashboard.component';
import { Employer_Pending_FollowUpComponent } from './Employer_Pending_FollowUp/Employer_Pending_FollowUp.component';
import { Employers_Tomorrows_followupComponent } from './Employers_Tomorrows_followup/Employers_Tomorrows_followup.component';
import { Employers_Today_followupComponent } from './Employers_Today_followup/Employers_Today_followup.component';
import { TodoComponent } from './Todo/Todo.component';
import { Agreed_EmployerComponent } from './Agreed_Employer/Agreed_Employer.component';
import { Candidate_Document_ReportComponent } from './Candidate_Document_Report/Candidate_Document_Report.component';
import { Monthly_Sales_ReportComponent } from './Monthly_Sales_Report/Monthly_Sales_Report.component';
import { Job_Interview_ReportComponent } from './Job_Interview_Report/Job_Interview_Report.component';
import { Meeting_FollowupComponent } from './Meeting Followup/Meeting_Followup.component';
import { Pending_Interview_ReportComponent } from './Pending_Interview_Report/Pending_Interview_Report.component';
import { Visa_ReportComponent } from './Visa_Report/Visa_Report.component';
import { Job_DashboardComponent } from './Job_Dashboard/Job_Dashboard.component';
import { Interview_Outcome_ReportComponent } from './Interview_Outcome_Report/Interview_Outcome_Report.component';
import { MilestoneComponent } from './Milestone/Milestone.component';
 //import { Userwise_SummaryComponent } from './Userwise_Summary/Userwise_Summary.component';
 
 //import { Enquiry_Source_ReportComponent } from './Enquiry_Source_Report/Enquiry_Source_Report.component';
 export const AdminRoutes: Routes = [
     {
         path: '',
         component: AdminComponent,
         children: [
             { path: '', redirectTo: '/User_Details', pathMatch: 'full' },
             { path: 'User_Details', component: User_DetailsComponent },
             {path:'Department',component: DepartmentComponent},
             {path:'Branch',component: BranchComponent},
             {path:'Department_Status',component: Department_StatusComponent},
             {path:'Country',component: CountryComponent},
             {path:'Course',component: CourseComponent},
             {path:'Course_Intake',component: Course_IntakeComponent},
             {path:'Document',component: DocumentComponent},
             {path:'Enquiry_Source',component: Enquiry_SourceComponent},
             {path:'Duration',component: DurationComponent},
             {path:'Intake',component: IntakeComponent},
             {path:'Internship',component: InternshipComponent},
             {path:'Level_Detail',component: Level_DetailComponent},
             {path:'Candidate',component: StudentComponent},
             {path:'Candidate_Document',component: Student_DocumentComponent},
             {path:'Candidate_Message',component: Student_MessageComponent},
             {path:'Candidate_Status',component: Student_StatusComponent},
             {path:'Enquiry_Source',component: Enquiry_SourceComponent},
             {path:'Subject',component: SubjectComponent},
             {path:'University',component: UniversityComponent},
             {path:'Agent',component: AgentComponent},
              {path:'Home_Page',component: Home_PageComponent},
              {path:'Dashboard',component: DashboardComponent},
            {path:'Course_Import',component: Course_ImportComponent},
            {path:'Candidate_Report',component: Student_ReportComponent},
            {path:'Work_report',component:Work_reportComponent },
            {path:'Account_Group',component: Account_GroupComponent},
            {path:'Client_Accounts',component: Client_AccountsComponent},
            {path:'Remarks',component: RemarksComponent},
            {path:'TimeTrack',component: TimeTrackComponent},
            {path:'Registration_Report',component:Registration_ReportComponent},
            {path:'Efficiency_Report',component:Efficiency_ReportComponent},
            {path:'Candidate_Import',component:Student_ImportComponent},
            {path:'Pending_FollowUp',component:Pending_FollowUpComponent},
            {path:'Fees',component:FeesComponent},
            {path:'Fees_Receipt_Report',component:Fees_Receipt_ReportComponent},
            {path:'Enquiry_Source_Summary',component:Enquiry_Source_SummaryComponent},
            {path:'Counselor_Fees_Receipt_Report',component:Counselor_Fees_Receipt_ReportComponent},
            {path:'Counselor_Registration_Report',component:Counselor_Registration_ReportComponent},
            {path:'Candidate_Summary_Report',component:Student_Summary_ReportComponent},
            {path:'Staff_Target_Report',component:Staff_Target_ReportComponent},
            {path:'Candidate_Search',component:Student_SearchComponent},
            {path:'Work_Summary',component:Work_SummaryComponent},
            {path:'Userwise_Summary',component:Userwise_SummaryComponent},
            {path:'Branchwise_Summary',component:Branchwise_SummaryComponent},
            {path:'PageA',component:PageAComponent},
            {path:'PageC',component:PageCComponent},
            {path:'PageB',component:PageBComponent},
            {path:'Enquiry_Source_Report',component:Enquiry_Source_ReportComponent}, 
            {path:'Receipt_Summary_Report',component:Receipt_Summary_ReportComponent},
            {path:'Registration_Summary',component:Registration_SummaryComponent},
            {path:'Enquiry_Conversion',component: Enquiry_ConversionComponent},
            {path:'Employee_Summary',component: Employee_SummaryComponent},
            {path:'User_Role',component: User_RoleComponent},
            {path:'Company',component: CompanyComponent},
            {path:'Settings',component: SettingsComponent},
             {path:'Documentation_Report',component: Documentation_ReportComponent},
             {path:'Work_History',component: Work_HistoryComponent},
             {path:'Registration_EnquirySource',component: Registration_EnquirySourceComponent},
             {path:'Details_check',component: Details_checkComponent}, 
             {path:'Check_List',component: Check_ListComponent}, 
             {path:'Agent_Details',component:Agent_DetailsComponent},
             {path:'Application_Report',component:Application_ReportComponent},
             {path:'Task',component:TaskComponent},
             {path:'Notification',component:NotificationComponent},
             {path:'Receipt_Confirmation',component:Receipt_ConfirmationComponent},
             {path:'Refund_Confirmation',component:Refund_ConfirmationComponent},
             {path:'Refund_Approval',component:Refund_ApprovalComponent},
             {path:'Application_Dashboard',component:Application_DashboardComponent},
             {path:'Candidate_Task',component:Student_TaskComponent},
             {path:'Passport_Expiry_Report',component:Passport_Expiry_ReportComponent},
             {path:'Application_Status',component:Application_StatusComponent},
             {path:'Task_Item',component:Task_ItemComponent},
             {path:'Bph_Report',component:Bph_ReportComponent},
             {path:'Application_List',component:Application_ListComponent},
             {path:'Application_Settings',component:Application_SettingsComponent},
             {path:'DocumentName',component:DocumentNameComponent},
             {path:'Accounts',component:AccountsComponent},
             {path:'Data_Migration',component:Data_MigrationComponent},
             {path:'Fees_Pending_Report',component:Fees_Pending_ReportComponent},
             {path:'Class_Summary',component:Class_SummaryComponent},
             {path:'Class',component:ClassComponent},
             {path:'Enquirywise_Status_Report',component:Enquirywise_Status_ReportComponent},
             {path:'Department_Status_Report',component:Department_Status_ReportComponent},
             {path:'FollowUp_Status_Report',component:FollowUp_Status_ReportComponent},
             {path:'Department_Report',component:Department_ReportComponent},
             {path:'Attendance_Report',component:Attendance_ReportComponent},
             {path:'Reference',component:ReferenceComponent},
             {path:'Task_Followup_Report',component:Student_Task_Followup_ReportComponent},

             {path:'Tag',component:TagComponent},
             {path:'Tag_Category',component:Tag_CategoryComponent},

             {path:'Maximum_Qualification',component:Max_QualificationComponent},
             {path:'Level',component:LevelComponent},
             {path:'Job_Posting',component:Job_PostingComponent},
             {path:'Agent_Data',component:Agent_DataComponent},
             {path:'Job_Category',component:Job_CategoryComponent},
             {path:'Job',component:JobComponent},
             {path:'Pending_Fees_Report',component:Pending_Fees_ReportComponent},
             {path:'Enquiry_report',component:Enquiry_reportComponent},
             {path:'Chat_Window',component:Chat_WindowComponent},
             {path:'B2B_Agencies',component:B2B_AgenciesComponent},
             {path:'Work_Details_Report',component:Work_Details_ReportComponent},

             {path:'Employer',component:EmployerComponent},
             {path:'Job_Summary',component:Job_SummaryComponent},
             {path:'Interview_Report',component:Interview_ReportComponent},
             {path:'Pending_Task_Report',component:Pending_Task_ReportComponent},
             {path:'Employer_Details',component:Employer_DetailsComponent},
             {path:'Tomorrows_followup',component:Tomorrows_followupComponent},
             {path:'Employer_Dashboard',component:Employer_DashboardComponent},
             {path:'Employer_Pending_FollowUp',component:Employer_Pending_FollowUpComponent},
             {path:'Employers_Tomorrows_followup',component:Employers_Tomorrows_followupComponent},
             {path:'Employers_Today_followup',component:Employers_Today_followupComponent},
             {path:'Todo',component:TodoComponent},
             {path:'Agreed_Employer',component:Agreed_EmployerComponent},
             {path:'Candidate_Document_Report',component:Candidate_Document_ReportComponent},
             {path:'Monthly_Sales_Report',component:Monthly_Sales_ReportComponent},
             {path:'Job_Interview_Report',component:Job_Interview_ReportComponent},
             {path:'Meeting_Followup',component:Meeting_FollowupComponent},
             {path:'Pending_Interview_Report',component:Pending_Interview_ReportComponent},
             {path:'Job_Dashboard',component:Job_DashboardComponent},

             {path:'Visa_Report',component:Visa_ReportComponent},
             {path:'Interview_Outcome_Report',component:Interview_Outcome_ReportComponent},
             {path:'Milestone',component:MilestoneComponent},
            //  {path:'Employers_Tomorrows_followup',component:Employers_Tomorrows_followupComponent},
             
             //{path:'Enquiry_Source_Report',component:Enquiry_Source_ReportComponent},
             // Always put last, if no routes defined fall into this path, 
             // Routes define under this will not work
             { path: '**', redirectTo: '/auth/login' }
             
         ]
     }
 ];
 