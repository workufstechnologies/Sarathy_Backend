import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Job_Category} from '../../../models/Job_Category';

import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Job_Category_Service } from 'app/services/Job_Category.Service';


@Component({
selector: 'app-Job_Category',
templateUrl: './Job_Category.component.html',
styleUrls: ['./Job_Category.component.css']
})
export class Job_CategoryComponent implements OnInit {
Job_Category_Data:Job_Category[]
Job_Category_:Job_Category= new Job_Category();

Job_Category_Name_Search:string;


Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Job_Category_Edit:boolean;
Job_Category_Save:boolean;
Job_Category_Delete:boolean;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";

constructor(public Job_Category_Service_:Job_Category_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));


    {

     this.Page_Load()
    }
}


Page_Load()
{
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 250;
    this.Clr_Job_Category();
    this.Get_Menu_Status(145,this.Login_User);

    this.Search_Job_Category();
    this.Entry_View=false;

    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 200;
    this.myTotalHeight=this.myTotalHeight-90;
    this.myInnerHeight = this.myInnerHeight - 230;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
this.issLoading = true;
this.Job_Category_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            
  
    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==145)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==145)
        {
            
        

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
                this.Job_Category_Edit=this.Permissions.Edit;
                this.Job_Category_Save=this.Permissions.Save;
                this.Job_Category_Delete=this.Permissions.Delete;
    
        }

    }

},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}


Create_New()
    {
        this.Entry_View = true;
        this.Clr_Job_Category();
    }

Close_Click()
    {
        this.Entry_View = false;
    }

trackByFn(index, item) 
    {
        return index;
    }


 Clr_Job_Category()
 {
this.Job_Category_.Job_Category_Id=0;
this.Job_Category_.Job_Category_Name="";


}
Search_Job_Category()
{
this.issLoading=true;

this.Job_Category_Service_.Search_Job_Category(this.Job_Category_Name_Search).subscribe(Rows => 
    {

    this.Job_Category_Data=Rows[0];
    this.Total_Entries=this.Job_Category_Data.length;
    if(this.Job_Category_Data.length==0)
    {
        this.issLoading=false;
        const dialogRef = this.dialogBox.open
        (DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
    }
    this.issLoading=false;
    },
    Rows => { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            });
}

Delete_Job_Category(Job_Category_Id,index)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
    this.Search_Job_Category();
    dialogRef.afterClosed().subscribe(result =>
    {
        if(result=='Yes')
        {
            this.issLoading=true;
            this.Job_Category_Service_.Delete_Job_Category(Job_Category_Id).subscribe(Delete_status => 
                {
                    if(Number(Delete_status[0][0].Job_Category_Id_)>0)
                    {
                        this.Job_Category_Data.splice(this.EditIndex, 1);
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
                        this.Search_Job_Category();
                    }
                    else if(Number(Delete_status[0][0].Job_Category_Id_)== -2)
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
                    }
                    else
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                    }
                    this.issLoading=false;
                },
                Rows => { 
                            this.issLoading=false;
                            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                        });
        }
    });
}


Save_Job_Category()
{
    if (this.Job_Category_.Job_Category_Name == undefined || this.Job_Category_.Job_Category_Name== null || this.Job_Category_.Job_Category_Name == undefined || this.Job_Category_.Job_Category_Name=='') 
    {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter job Sector', Type: "3" } });
        return;
    }
    
    this.issLoading=true;
    this.Job_Category_Service_.Save_Job_Category(this.Job_Category_).subscribe(Save_status => 
        {
            Save_status=Save_status[0];
            if(Number(Save_status[0].Job_Category_Id_)>0)
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
                this.Search_Job_Category();
                this.Clr_Job_Category();
            }
            else
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            }   
            this.issLoading=false;
        },
        Rows => 
        { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error,Type:"2"}});
        });
}


Edit_Job_Category(Job_Category_e:Job_Category,index)
{  
    this.Entry_View=true;
    this.Job_Category_=Job_Category_e;
    this.Job_Category_=Object.assign({},Job_Category_e);
}

}



