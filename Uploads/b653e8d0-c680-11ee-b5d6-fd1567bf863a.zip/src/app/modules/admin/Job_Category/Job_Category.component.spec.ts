import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Job_CategoryComponent } from './Job_Category.component';
describe('Job_CategoryComponent', () => {
let component: Job_CategoryComponent;
let fixture: ComponentFixture<Job_CategoryComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Job_CategoryComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Job_CategoryComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});