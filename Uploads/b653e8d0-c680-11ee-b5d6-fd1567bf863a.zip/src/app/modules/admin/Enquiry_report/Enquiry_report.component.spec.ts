import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Enquiry_reportComponent } from './Enquiry_report.component';


describe('Enquiry_reportComponent', () => {
  let component: Enquiry_reportComponent;
  let fixture: ComponentFixture<Enquiry_reportComponent>;

  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [Enquiry_reportComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Enquiry_reportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
