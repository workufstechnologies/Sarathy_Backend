import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Employer_Pending_FollowUpComponent } from './Employer_Pending_FollowUp.component';

describe('Pending_FollowUpComponent', () => {
  let component: Employer_Pending_FollowUpComponent;
  let fixture: ComponentFixture<Employer_Pending_FollowUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Employer_Pending_FollowUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Employer_Pending_FollowUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
