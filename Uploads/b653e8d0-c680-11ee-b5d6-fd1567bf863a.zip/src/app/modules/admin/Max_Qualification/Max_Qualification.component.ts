import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Max_Qualification} from '../../../models/Max_Qualification';
import { Max_Qualification_Service } from '../../../services/Max_Qualification.Service';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';
import { Language_Proficiency } from 'app/models/Language_Proficiency';
import { Level_Service } from 'app/services/Level.Service';
import { Level } from 'app/models/Level';


@Component({
selector: 'app-Max_Qualification',
templateUrl: './Max_Qualification.component.html',
styleUrls: ['./Max_Qualification.component.css']
})
export class Max_QualificationComponent implements OnInit {
Max_Qualification_Data:Max_Qualification[]
Max_Qualification_:Max_Qualification= new Max_Qualification();

Max_Qualification_Name_Search:string;


Entry_View:boolean=true;
EditIndex: number;
Total_Entries: number;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Max_Qualification_Edit:boolean;
Max_Qualification_Save:boolean;
Max_Qualification_Delete:boolean;
myInnerHeight: number;
myTotalHeight:number;
Login_User:string="0";


Level_1_Data: Level[];
	Level_1_Data_Filter: Level[];
	Level_1_: Level = new Level();
	Level_1_Temp_: Level = new Level();



constructor(public Max_Qualification_Service_:Max_Qualification_Service,public Level_Service_: Level_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));


    {

     this.Page_Load()
    }
}


Page_Load()
{
    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 250;
    this.Clr_Max_Qualification();
    this.Get_Menu_Status(137,this.Login_User);

    this.Search_Max_Qualification();
    this.Entry_View=false;

    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 200;
    this.myTotalHeight=this.myTotalHeight-90;
    this.myInnerHeight = this.myInnerHeight - 230;
}

Get_Menu_Status(Menu_id, Login_user_id)
{
this.issLoading = true;
this.Max_Qualification_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            
  
    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==137)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==137)
        {
            
        

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
                this.Max_Qualification_Edit=this.Permissions.Edit;
                this.Max_Qualification_Save=this.Permissions.Save;
                this.Max_Qualification_Delete=this.Permissions.Delete;
    
        }

    }

},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}


Create_New()
    {
        this.Entry_View = true;
        this.Clr_Max_Qualification();
    }

Close_Click()
    {
        this.Entry_View = false;
    }

trackByFn(index, item) 
    {
        return index;
    }


 Clr_Max_Qualification()
 {
this.Max_Qualification_.Max_Qualification_Id=0;
this.Max_Qualification_.Max_Qualification_Name="";
this.Level_1_=null;


}
Search_Max_Qualification()
{
this.issLoading=true;
debugger;
this.Max_Qualification_Service_.Search_Max_Qualification(this.Max_Qualification_Name_Search).subscribe(Rows => 
    {
debugger;
    this.Max_Qualification_Data=Rows[0];
    this.Total_Entries=this.Max_Qualification_Data.length;
    if(this.Max_Qualification_Data.length==0)
    {
        this.issLoading=false;
        const dialogRef = this.dialogBox.open
        (DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
    }
    this.issLoading=false;
    },
    Rows => { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            });
}

Delete_Max_Qualification(Max_Qualification_Id,index)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Do you want to delete ?',Type:true,Heading:'Confirm'}});
    this.Search_Max_Qualification();
    dialogRef.afterClosed().subscribe(result =>
    {
        if(result=='Yes')
        {
            this.issLoading=true;
            this.Max_Qualification_Service_.Delete_Max_Qualification(Max_Qualification_Id).subscribe(Delete_status => 
                {
                    if(Number(Delete_status[0][0].Max_Qualification_Id_)>0)
                    {
                        this.Max_Qualification_Data.splice(this.EditIndex, 1);
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Deleted',Type: "false"}});
                        this.Search_Max_Qualification();
                    }
                    else if(Number(Delete_status[0][0].Max_Qualification_Id_)== -2)
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
                    }
                    else
                    {
                        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                    }
                    this.issLoading=false;
                },
                Rows => { 
                            this.issLoading=false;
                            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
                        });
        }
    });
}


Save_Max_Qualification()
{
    if (this.Max_Qualification_.Max_Qualification_Name == undefined || this.Max_Qualification_.Max_Qualification_Name== null || this.Max_Qualification_.Max_Qualification_Name == undefined || this.Max_Qualification_.Max_Qualification_Name=='') 
    {
        const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Specialization', Type: "3" } });
        return;
    }



    if (
        this.Level_1_ == undefined ||
        this.Level_1_ == null ||
        this.Level_1_.Level_Id == undefined ||
        this.Level_1_.Level_Id == 0
    ) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Select Level", Type: "3" },
        });
        return;
    }



    this.Max_Qualification_.Level_Id=this.Level_1_.Level_Id;
    this.Max_Qualification_.Level_Name=this.Level_1_.Level_Name;

    debugger;
    this.issLoading=true;
    this.Max_Qualification_Service_.Save_Max_Qualification(this.Max_Qualification_).subscribe(Save_status => 
        {
            debugger;
            Save_status=Save_status[0];
            if(Number(Save_status[0].Max_Qualification_Id_)>0)
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
                this.Search_Max_Qualification();
                this.Clr_Max_Qualification();
            }
            else
            {
                const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
            }   
            this.issLoading=false;
        },
        Rows => 
        { 
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:Rows.error,Type:"2"}});
        });
}


Edit_Max_Qualification(Max_Qualification_e:Max_Qualification,index)
{  

    debugger
    this.Entry_View=true;
    this.Max_Qualification_=Max_Qualification_e;
    this.Max_Qualification_=Object.assign({},Max_Qualification_e);

    this.Level_1_Temp_.Level_Id = Max_Qualification_e.Level_Id;
    this.Level_1_Temp_.Level_Name = Max_Qualification_e.Level_Name;
    this.Level_1_ = Object.assign({}, this.Level_1_Temp_);




}



Search_Level_Typeahead(event: any) {
		
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Level_1_Data=[]

    if (this.Level_1_Data == undefined || this.Level_1_Data.length == 0) {
        this.issLoading = true;

        this.Level_Service_.Search_Level_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Level_1_Data = Rows[0];
                    this.Level_1_Data_Filter = [];
                    for (var i = 0; i < this.Level_1_Data.length; i++) {
                        if (
                            this.Level_1_Data[i].Level_Name.toLowerCase().includes(Value)
                        )
                            this.Level_1_Data_Filter.push(this.Level_1_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Level_1_Data_Filter = [];
        for (var i = 0; i < this.Level_1_Data.length; i++) {
            if (this.Level_1_Data[i].Level_Name.toLowerCase().includes(Value))
                this.Level_1_Data_Filter.push(this.Level_1_Data[i]);
        }
    }
}

display_Level(Level_e: Level) 
{
    if (Level_e) {
        return Level_e.Level_Name;
    }
}


}



