import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Max_QualificationComponent } from './Max_Qualification.component';
describe('Max_QualificationComponent', () => {
let component: Max_QualificationComponent;
let fixture: ComponentFixture<Max_QualificationComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Max_QualificationComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Max_QualificationComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});