import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Job_Interview_ReportComponent} from './Job_Interview_Report.component';
describe('Home_PageComponent', () => {
let component: Job_Interview_ReportComponent;
let fixture: ComponentFixture<Job_Interview_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Job_Interview_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Job_Interview_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

