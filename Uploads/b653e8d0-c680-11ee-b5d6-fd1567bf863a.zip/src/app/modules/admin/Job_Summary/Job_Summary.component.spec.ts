import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Job_SummaryComponent} from './Job_Summary.component';
describe('Home_PageComponent', () => {
let component: Job_SummaryComponent;
let fixture: ComponentFixture<Job_SummaryComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Job_SummaryComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Job_SummaryComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

