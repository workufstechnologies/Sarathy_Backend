import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Job_DashboardComponent } from './Job_Dashboard.component';
describe('Home_PageComponent', () => {
let component: Job_DashboardComponent;
let fixture: ComponentFixture<Job_DashboardComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Job_DashboardComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Job_DashboardComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

