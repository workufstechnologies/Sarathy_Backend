import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Monthly_Sales_ReportComponent } from './Monthly_Sales_Report.component';

describe('Tomorrows_followupComponent', () => {
  let component: Monthly_Sales_ReportComponent;
  let fixture: ComponentFixture<Monthly_Sales_ReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Monthly_Sales_ReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Monthly_Sales_ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
