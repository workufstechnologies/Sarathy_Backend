import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Agent_Details_Service } from '../../../services/Agent_Details.service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Agent } from '../../../models/Agent';
import {MatDialog} from '@angular/material';import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component';@Component({
selector: 'app-Agent_Details',
templateUrl: './Agent_Details.component.html',
styleUrls: ['./Agent_Details.component.css']
})
export class Agent_DetailsComponent implements OnInit {
Agent_Details_Data:Agent[]
Agent_Details_Typeahead_Data:Agent[]
Agent_Details_:Agent= new Agent();
Agent_Details_Temp:Agent= new Agent();
Under_Role_:Agent= new Agent();
Agent_Details_Name_Search:string;
Search_Agent_Details_:string;
Entry_View:boolean=true;
myInnerHeight: number;
EditIndex: number;
Id:number;
Name:string;
Total_Entries: number=0;
color = 'primary';
mode = 'indeterminate';
value = 50;
issLoading: boolean;
Permissions: any;
Agent_Details_Edit:boolean;
Agent_Details_Save:boolean;
Agent_Details_Delete:boolean;
Login_User: string = "0";
myTotalHeight:number;



constructor(public Agent_Details_Service_:Agent_Details_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) { }
ngOnInit() 
    {
        this.Agent_Details_Typeahead_Data = [];
    this.Login_User = localStorage.getItem("Login_User");

        
    // this.Permissions = Get_Page_Permission(66);
    // if(this.Permissions==undefined || this.Permissions==null)
    // {
    // localStorage.removeItem('token');
    // this.router.navigateByUrl('Home_Page');
    // }
    // else
    {
    // this.Agent_Details_Edit=this.Permissions.Edit;
    // this.Agent_Details_Save=this.Permissions.Save;
    // this.Agent_Details_Delete=this.Permissions.Delete;
    this.Page_Load()
    }
}
Page_Load()
{
    this.Get_Menu_Status(66,this.Login_User); 

    this.myInnerHeight = (window.innerHeight);
    this.myInnerHeight = this.myInnerHeight - 280;
    this.Clr_Agent_Details();
    this.Search_Agent_Details();
    //this.Load_Agent_Details();
    this.Entry_View=false;
    this.myInnerHeight = (window.innerHeight);
    this.myTotalHeight=this.myInnerHeight - 200;
    this.myTotalHeight=this.myTotalHeight-40;
    this.myInnerHeight = this.myInnerHeight - 230;
}


Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Agent_Details_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==66)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        if(Menu_id==66)
        {
            
            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               
                this.Agent_Details_Edit=this.Permissions.Edit;
                this.Agent_Details_Save=this.Permissions.Save;
                this.Agent_Details_Delete=this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}

trackByFn(index, item) 
{
return index;
}
Create_New()                           
{
    this.Entry_View = true;
    this.Clr_Agent_Details();
}
Close_Click()
{
    this.Entry_View = false;
}
Clr_Agent_Details()
 {
     this.Agent_Details_.Agent_Id = 0;
    this.Agent_Details_.Agent_Name=null;
    this.Under_Role_=null;
    this.Agent_Details_.Phone=""
    this.Agent_Details_.Email=""
    this.Agent_Details_.Address=""
    this.Agent_Details_.Description=""
    
   
}

// Load_Agent_Details(event: any) 
// {           
//     var Value = "";
//     if (event.target.value == "")
//     Value = undefined;
//     else
//     Value = event.target.value;
//     this.issLoading=true;
//         this.Agent_Details_Service_.Load_Agent_Details(Value).subscribe(Rows => {
              
//             if (Rows != null) {
//             this.Agent_Details_Typeahead_Data=Rows[0];
//             }
//             this.issLoading=false;
//              },
//         Rows => 
//         {
//             this.issLoading=false;
//        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
//         });
// }     
// display_Under_Role(Agent_Details_: Agent_Details)
// {      
//        if (Agent_Details_) { return Agent_Details_.Name;  }
// }
Search_Agent_Details()
{       
       
        this.issLoading=true;
        this.Agent_Details_Service_.Search_Agent_Details(this.Agent_Details_Name_Search).subscribe(Rows => {
              
              
        this.Agent_Details_Data=Rows[0];
        this.Total_Entries=this.Agent_Details_Data.length;
        if(this.Agent_Details_Data.length==0)
        {
             
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'No Details Found',Type:"3"}});
        }
         this.issLoading=false;
        },
        Rows => 
        {
            this.issLoading=false;
            const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
        });
}
Delete_Agent_Details(Agent_Id_,index)
    {
          const dialogRef = this.dialogBox.open
    ( DialogBox_Component, {panelClass:'Dialogbox-Class'
    ,data:{Message:'Do you want to delete ?',Type:"true",Heading:'Confirm'}});
    dialogRef.afterClosed().subscribe(result =>
    {
    if(result=='Yes')
    {
        this.issLoading=true;
    this.Agent_Details_Service_.Delete_Agent_Details(Agent_Id_).subscribe(Delete_status => {
          debugger
    if(Number(Delete_status[0][0].Agent_Id_)>0){
    this.Agent_Details_Data.splice(this.EditIndex, 1);
    const dialogRef = this.dialogBox.open
    ( DialogBox_Component, {panelClass:'Dialogbox-Class'
    ,data:{Message:'Deleted',Type:"false"}});
    this.Search_Agent_Details()
    }else if(Number(Delete_status[0][0].Agent_Id_)== -2)
    {
        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Already in Use, Cannot be Deleted!',Type:"2"}});
    }else{
        const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
    }
    this.issLoading=false;
    },
    Rows => { this.issLoading=false;
     const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });
    
    }
    });


}
Save_Agent_Details()
{

    if(this.Agent_Details_.Agent_Name==undefined || this.Agent_Details_.Agent_Name==null || this.Agent_Details_.Agent_Name=="")
    {
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Enter Name',Type:"3"}}); 
    return  
    }

    // if(this.Agent_Details_.Phone==undefined || this.Agent_Details_.Phone==null || this.Agent_Details_.Phone=="")
    // {
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Enter Phone',Type:"3"}}); 
    // return  
    // }

    // if(this.Agent_Details_.Phone.toString().length!=10 )
    // {
    //     const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class'  ,data:{Message:'Enter valid Phone Number',Type:"3"}});
    //     return
    // }
    // if(this.Agent_Details_.Phone!=''&&this.Agent_Details_.Phone!=null&&this.Agent_Details_.Phone!=undefined)
    // {
    //     if(this.Agent_Details_.Phone.toString().length!=10 )
    //     {
    //         const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class'  ,data:{Message:'Enter valid Phone Number',Type:"3"}});
    //         return
    //     }
    // }

    // if(this.Agent_Details_.Email==undefined || this.Agent_Details_.Email==null || this.Agent_Details_.Email=="")
    // {
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Enter Email',Type:"3"}}); 
    // return  
    // }

    // if(this.Agent_Details_.Address==undefined || this.Agent_Details_.Address==null || this.Agent_Details_.Address=="")
    // {
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Enter Address',Type:"3"}}); 
    // return  
    // }

    // if(this.Agent_Details_.Description==undefined || this.Agent_Details_.Description==null || this.Agent_Details_.Description=="")
    // {
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Enter Description',Type:"3"}}); 
    // return  
    // }

    else{
    document.getElementById("Save_Button").hidden=true;
    this.issLoading=true;
    
    this.Agent_Details_Service_.Save_Agent_Details(this.Agent_Details_).subscribe(Save_status => {
        
        this.issLoading=false;
    Save_status=Save_status[0];
    if(Save_status!=undefined)
    {
        
    if (Number(Save_status[0].Agent_Id_) > 0) 
    {
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
    document.getElementById("Save_Button").hidden=false;
    this.Clr_Agent_Details();
    this.Search_Agent_Details();
    }
    }
    else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
    document.getElementById("Save_Button").hidden=false;
    }
    this.issLoading=false;
    },
    Rows => { 
        this.issLoading=false;
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
    document.getElementById("Save_Button").hidden=false;
    });
    
    }
    }



Edit_Agent_Details(Agent_Details_e:Agent,index)
{
      
this.Entry_View=true;
this.Agent_Details_=Agent_Details_e;
this.Agent_Details_=Object.assign({},Agent_Details_e);
 
}
}

