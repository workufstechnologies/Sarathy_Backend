import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Candidate_Document_ReportComponent} from './Candidate_Document_Report.component';
describe('Home_PageComponent', () => {
let component: Candidate_Document_ReportComponent;
let fixture: ComponentFixture<Candidate_Document_ReportComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ Candidate_Document_ReportComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(Candidate_Document_ReportComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

