import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Agreed_EmployerComponent } from './Agreed_Employer.component';

describe('Tomorrows_followupComponent', () => {
  let component: Agreed_EmployerComponent;
  let fixture: ComponentFixture<Agreed_EmployerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Agreed_EmployerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Agreed_EmployerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
