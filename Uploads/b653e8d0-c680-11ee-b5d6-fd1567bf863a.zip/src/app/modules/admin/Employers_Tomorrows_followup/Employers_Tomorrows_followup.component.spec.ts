import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Employers_Tomorrows_followupComponent } from './Employers_Tomorrows_followup.component';

describe('Tomorrows_followupComponent', () => {
  let component: Employers_Tomorrows_followupComponent;
  let fixture: ComponentFixture<Employers_Tomorrows_followupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Employers_Tomorrows_followupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Employers_Tomorrows_followupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
