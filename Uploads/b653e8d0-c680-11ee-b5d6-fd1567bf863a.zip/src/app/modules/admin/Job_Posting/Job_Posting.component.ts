import { Component, OnInit,Input,Injectable, ErrorHandler } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of as observableOf, merge, throwError } from 'rxjs';
import { Job_Posting_Service } from '../../../services/Job_Posting.Service';
import { DialogBox_Component } from '../DialogBox/DialogBox.component';
import { Job_Posting} from '../../../models/Job_Posting';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA,MatDialogConfig, DateAdapter, MAT_DATE_LOCALE, MAT_DATE_FORMATS} from '@angular/material';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';
import { getParseErrors, syntaxError } from '@angular/compiler';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { ROUTES,Get_Page_Permission } from '../../../components/sidebar/sidebar.component'
//import { ConsoleReporter } from 'jasmine';
import { error } from '@angular/compiler/src/util';
import { Sub_Status } from 'app/models/Sub_Status';
import { Job_Status } from 'app/models/Job_Status';
import { User_Details } from 'app/models/User_Details';
import { Student_Service } from 'app/services/Student.Service';
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import * as _moment from 'moment';
import {default as _rollupMoment} from 'moment';
import { environment } from 'environments/environment';
import * as io from "socket.io-client";
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { event } from 'jquery';
import { Max_Qualification } from 'app/models/Max_Qualification';
import { Max_Qualification_Service } from 'app/services/Max_Qualification.Service';
import { Experience } from 'app/models/Experience';
import { University_Service } from 'app/services/University.service';
import { Employer } from 'app/models/Employer';
import { Job_Category } from 'app/models/Job_Category';
import { Job_Category_Service } from 'app/services/Job_Category.Service';
import { Job_Service } from 'app/services/Job.Service';
import { Job } from 'app/models/Job';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
parse: {
dateInput: 'DD/MM/YYYY',
},
display: {
dateInput: 'DD/MM/YYYY',monthYearLabel: 'MMM YYYY',dateA11yLabel: 'DD/MM/YYYY',monthYearA11yLabel: 'MMMM YYYY',
},
};

@Component({
selector: 'app-Job_Posting',
templateUrl: './Job_Posting.component.html',
styleUrls: ['./Job_Posting.component.css'],
providers: [
    {
        provide: DateAdapter,
        useClass: MomentDateAdapter,
        deps: [MAT_DATE_LOCALE],
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
],
})
export class  Job_PostingComponent implements OnInit {

url = environment.NotificationPath; // 'http://regnewapi.trackbox.co.in:3646/'
private socket;

Job_Posting_Data:Job_Posting[]
Job_Posting_:Job_Posting= new Job_Posting();
Job_Posting_Name_Search:string;
Entry_View:boolean=true;
Sub_Status_View:boolean=true;
Status_View:boolean=true;
EditIndex: number;
Menu_Id:number=114;
color = 'primary';
mode = 'indeterminate';
value = 50;Total_Entries:Number;
issLoading: boolean;
Job_Posting_Edit:boolean;
Job_Posting_Save:boolean;
Job_Posting_Delete:boolean;
array:any;
myInnerHeight: number;
myInnerHeightTwo: number;
myTotalHeight:number;
Login_User:string="0";
Permissions: any;
Job_Posting_Data1:Job_Posting[]

Sub_Status_Data:Sub_Status[]
Sub_Status_:Sub_Status= new Sub_Status();
Sub_Status_Search:string;


Max_Qualification_Data: Max_Qualification[];
	Max_Qualification_Data_Filter: Max_Qualification[];
	Max_Qualification_: Max_Qualification = new Max_Qualification();
	Max_Qualification_Temp_: Max_Qualification = new Max_Qualification();

    Employer_: Employer = new Employer();
    Employer_Search_: Employer = new Employer();
	Employer_Temp: Employer = new Employer();
	Employer_Data: Employer[];
	Employer_Tab_Data: Employer[];



    Employer_T_: Employer = new Employer();
    Employer_Search_T_: Employer = new Employer();
	Employer_Temp_T: Employer = new Employer();
	Employer_Data_T: Employer[];
	Employer_Tab_Data_T: Employer[];

    file_b2b_changed: boolean=false;
// Status_Type_:number=0;


// Job_Status_: Job_Status = new Job_Status();
// Job_Status_Temp: Job_Status = new Job_Status();
// Job_Status_Data: Job_Status[];

Job_Status_ :number =0;
Job_Country_:number =0;
Users_Data: User_Details[];
Users_Temp: User_Details = new User_Details();
User_Search: User_Details = new User_Details();

Search_FromDate: Date = new Date();
Search_ToDate: Date = new Date();
Look_In_Date: Boolean = true;

year: any;
month: any;
day: any;
date: any;
selectedPdfPreview: any='';
pdfload: boolean = true;
Search_JobName:string="";
Job_Data_2: Job[];
Job_Data_Filter_2: Job[];
Job_Data: Job_Posting[];
Job_Data_Filter: Job_Posting[];
Job_Temp: Job_Posting = new Job_Posting();
Job_: Job_Posting = new Job_Posting();

Experience_Data: Experience[];
	Experience_Data_Filter: Experience[];
	Experience_: Experience = new Experience();
	Experience__Temp_: Experience = new Experience();

    Page_Check:number=0;
    Job_Category_1_Data: Job_Category[];
	Job_Category_1_Data_Filter: Job_Category[];
	Job_Category_1_: Job_Category = new Job_Category();
	Job_Category_1_Temp_: Job_Category = new Job_Category();
	Job_Data_1: Job[];
	Job_Filter: Job[];
	Job_1: Job = new Job();
	Job_Temp_: Job = new Job();

    Job_Id_Local_Temp :number = 0;
    Job_Name_Local_Temp :string;

    job_dashboard_view:number;

constructor(public Student_Service_:Student_Service,
    public Job_Service_:Job_Service,
    public Job_Category_Service_: Job_Category_Service,private sanitizer: DomSanitizer,
    public University_Service_: University_Service,public Job_Posting_Service_:Job_Posting_Service,public Max_Qualification_Service_: Max_Qualification_Service, private route: ActivatedRoute, private router: Router,public dialogBox: MatDialog) {
    this.socket = io(this.url, {
        transports: ["websocket"],
        auth: {
            token: localStorage.getItem("token"),
        },
    });
    this.socket = io(this.url);
} 
ngOnInit() 
{
    this.Login_User=localStorage.getItem(("Login_User"));
    this.Page_Check = Number(localStorage.getItem("Page_Check"))
    this.Job_Id_Local_Temp = Number(localStorage.getItem("Job_Id"));
    this.Job_Name_Local_Temp = localStorage.getItem("Job_Name");

    this.job_dashboard_view = Number(localStorage.getItem("job_dashboard"));

    // if(this.job_dashboard_view>0)
    // {
    //     localStorage.removeItem('job_dashboard');
    // }
    

    localStorage.setItem('Page_Check','0');
    localStorage.setItem('Job_Id','0');
    localStorage.setItem('Job_Name','');
    // this.array=Get_Page_Permission(this.Menu_Id);
    // if(this.array==undefined || this.array==null)
    // {
    // localStorage.removeItem('token');
    // this.router.navigateByUrl('/auth/login');
    // }
    // else 
    {
    // this.Job_Posting_Edit= this.array.Edit;
    // this.Job_Posting_Save= this.array.Save;
    // this.Job_Posting_Delete= this.array.Delete;
this.Page_Load()
}}
Page_Load()
{
    this.Get_Menu_Status(139,this.Login_User); 
	this.myInnerHeight = window.innerHeight;
    this.myTotalHeight = this.myInnerHeight;
    this.myTotalHeight = this.myTotalHeight - 280;
    this.myInnerHeight = this.myInnerHeight - 210;
    this.myInnerHeightTwo = this.myInnerHeight - -100;
    
    this.Get_Lead_Load_Data_ByUser(this.Login_User);
    this.Clr_Job_Posting();
    this.Get_Student_PageLoadData_Dropdowns()

    this.Search_FromDate=new Date();
    this.Search_FromDate = this.New_Date(this.Search_ToDate);
    this.Search_ToDate=new Date();
    this.Search_ToDate = this.New_Date(this.Search_ToDate);
    // this.Search_Job_Posting();

  if(this.Job_Id_Local_Temp > 0)
    {
        this.Job_.Job_Id = this.Job_Id_Local_Temp;
        this.Job_.Job_Name = this.Job_Name_Local_Temp;
        this.Look_In_Date = false;
    }

     
    // this.myInnerHeight = (window.innerHeight);
    // this.myTotalHeight=this.myInnerHeight - 180;
    // this.myTotalHeight=this.myTotalHeight-40;
    // this.myInnerHeight = this.myInnerHeight - 250;

    if(this.Page_Check > 0)
    {
        this.Create_New_Job_Posting()
    }
    else
    {
        this.Entry_View=false;
        this.Status_View=true;
        this.Sub_Status_View=true;
        this.Search_Job_Posting();
    
    }
}

New_Date(Date_)
{
    this.date = Date_;
    this.year = this.date.getFullYear();
    this.month = this.date.getMonth() + 1;
    if (this.month < 10)
    {
        this.month = "0" + this.month;
    }
    this.day = this.date.getDate().toString();
    if (Number.parseInt(this.day) < 10)
    {
        this.day = "0" + this.day;
    }
    this.date = this.year + "-" + this.month + "-" + this.day;
    return this.date;
}


Get_Menu_Status(Menu_id, Login_user_id)
{
    
this.issLoading = false;
this.Job_Posting_Service_.Get_Menu_Status(Menu_id,Login_user_id).subscribe(Rows => {            

    
    if (Rows[0][0]==undefined)
    {
        if(Menu_id==139)
        {
        localStorage.removeItem('token');
        this.router.navigateByUrl('Home_Page');
        }
    }  
    else
    if (Rows[0][0].View >0) 
    {
        
        
        if(Menu_id==139)
        {
            
           debugger

            this.Permissions=Rows[0][0];
            if(this.Permissions==undefined || this.Permissions==null)
                {
                    localStorage.removeItem('token');
                    this.router.navigateByUrl('Home_Page');
                }
               
                this.Job_Posting_Edit= this.Permissions.Edit;
                this.Job_Posting_Save= this.Permissions.Save;
                this.Job_Posting_Delete= this.Permissions.Delete;
        }

    }
},
Rows => {
    this.issLoading = false;
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Error Occured', Type: "2" } });
});
}

Create_New_Job_Posting() 
{
this.Entry_View = true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Clr_Job_Posting();
}
Close_Click()
{
    debugger;
    if(this.Page_Check >= 0)
    {
        this.Entry_View=false;
        this.Status_View=true;
        this.Sub_Status_View=true;
        this.Search_Job_Posting();
    
        // this.router.navigateByUrl('/');
    }
    else{
        this.Entry_View = true;
    }
    // else
    // {
    //     this.Entry_View = false;
    //     this.Status_View=true;
    //     this.Sub_Status_View=true;
    //     this.Job_Data=[];
    //     this.Search_Job_Typeahead_1("");
    //     this.Clr_Job_Posting();
    // }


}
trackByFn(index, item) 
{
return index;
}

Clr_Job_Posting()
{

this.Job_Posting_Save =true;
this.Job_Posting_.Job_Posting_Id=0;
this.Job_Posting_.Details="";
this.Job_Posting_.Job_Name="";
this.Job_Posting_.Description="";
this.Job_Posting_.By_User=0;
this.Job_Posting_.Job_Status="";
this.Job_Posting_.Available_Vacancy="";
this.Job_Posting_.Experience_="";
this.Job_Posting_.No_of_Positions="";
this.Job_Posting_.Salary="";
this.Job_Posting_.Recruitment_Fees="";
this.Job_Posting_.Max_Qualification_="";
this.Job_Posting_.Currency=0;
this.Job_Status_=0;
this.Job_Country_=0;
this.Max_Qualification_=null;
this.Experience_=null;
this.Job_Category_1_=null;
this.Job_1=null;
this.Employer_Search_T_=null;
if (this.Users_Data != null && this.Users_Data != undefined)
this.User_Search = this.Users_Data[0];

// if (this.Employer_Data != null && this.Employer_Data != undefined)
// this.Employer_ = this.Employer_Data[0];

this.Job_Posting_.Notes="";
this.Job_Posting_.Mandatory="";
this.Job_Posting_.Location="";
// this.Job_Posting_.Interview_Date = new Date();
// this.Job_Posting_.Interview_Date = this.New_Date(this.Job_Posting_.Interview_Date);
this.Job_Posting_.Interview_Date ="";
this.Job_Posting_.Post_Filling_Date ="";
this.Job_Posting_.Job_Starting_Date ="";
this.Job_Posting_.Document_file =[];
this.Job_Posting_.Image_File_Name='';
}
show_Loader()
{

}
hide_Loader()
{

}
Search_Job_Posting()
{
    var Job_Id_=0;

    debugger
    var look_In_Date_Value=0,Usersearch=0,Job_Name_='',employer_id=0;
    if (this.Look_In_Date == true )
    look_In_Date_Value = 1;

    if (this.Job_.Job_Id != undefined && this.Job_.Job_Id != null)
Job_Id_ = this.Job_.Job_Id;
    
if (this.Job_.Job_Name=='')
Job_Name_=undefined;
 else
 Job_Name_=this.Job_.Job_Name;

if (this.User_Search.User_Details_Id != undefined && this.User_Search.User_Details_Id != null)
Usersearch = this.User_Search.User_Details_Id;

if (this.Employer_Search_.Employer_Id != undefined && this.Employer_Search_.Employer_Id  != null)
employer_id = this.Employer_Search_.Employer_Id ;
    

this.issLoading=true;
debugger
    
this.Job_Posting_Service_.Search_Job_Posting(
    moment(this.Search_FromDate).format('YYYY-MM-DD'),
    moment(this.Search_ToDate).format('YYYY-MM-DD'),
    look_In_Date_Value,
    Job_Id_,
    Job_Name_,
    Usersearch,
    employer_id,
    ).subscribe(Rows => {
this.Job_Posting_Data=Rows[0];
debugger
this.Total_Entries=this.Job_Posting_Data.length;

if(this.Job_Posting_Data.length==0)
{
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'No Details Found',Type:"3"}});
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
 const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

}

Delete_Job_Posting(Job_Posting_Id,index)
{debugger
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'Do you want to delete ?',Type:"true",Heading:'Confirm'}});
dialogRef.afterClosed().subscribe(result =>
{
if(result=='Yes')
{
    this.issLoading=true;
    debugger 
this.Job_Posting_Service_.Delete_Job_Posting(Job_Posting_Id).subscribe(Delete_status => {
    debugger
if(Number(Delete_status[0][0].Job_Posting_Id_)>0){
this.Job_Posting_Data.splice(this.EditIndex, 1);
const dialogRef = this.dialogBox.open
( DialogBox_Component, {panelClass:'Dialogbox-Class'
,data:{Message:'Deleted',Type:"false"}});

this.Job_.Job_Name="";
this.Search_Job_Typeahead_1('');
// this.Search_Job_Posting();
}
else if(Number(Delete_status[0][0].Job_Posting_Id_)== -2)
{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Cannot Delete!',Type:"2"}});
}else{
    const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
}
this.issLoading=false;
},
Rows => { this.issLoading=false;
 const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });

}
});
}

Job_Category_Change()
{
	this.Job_1=null;
	this.Job_Filter=[];


}

Save_Job_Posting()
{

    if(this.Job_Status_==1){ this.Job_Posting_.Job_Status="Active"};
    if(this.Job_Status_==2){ this.Job_Posting_.Job_Status="Inactive"}




    
    if(this.Job_Country_==1){ this.Job_Posting_.Job_Country="United Kingdom"};
    if(this.Job_Country_==2){ this.Job_Posting_.Job_Country="Ireland"}
debugger
    if(this.Job_Posting_.Interview_Date!=null || this.Job_Posting_.Interview_Date!=""||this.Job_Posting_.Interview_Date!=undefined )
    { this.Job_Posting_.Interview_Date = this.New_Date(new Date(moment(this.Job_Posting_.Interview_Date).format("YYYY-MM-DD")));}

    if(this.Job_Posting_.Interview_Date==null || this.Job_Posting_.Interview_Date==""||this.Job_Posting_.Interview_Date==undefined|| this.Job_Posting_.Interview_Date=="NaN-NaN-NaN" )
    { this.Job_Posting_.Interview_Date = ""}



    if(this.Job_Posting_.Post_Filling_Date!=null || this.Job_Posting_.Post_Filling_Date!=""||this.Job_Posting_.Post_Filling_Date!=undefined )
    { this.Job_Posting_.Post_Filling_Date = this.New_Date(new Date(moment(this.Job_Posting_.Post_Filling_Date).format("YYYY-MM-DD")));}

    if(this.Job_Posting_.Post_Filling_Date==null || this.Job_Posting_.Post_Filling_Date==""||this.Job_Posting_.Post_Filling_Date==undefined|| this.Job_Posting_.Post_Filling_Date=="NaN-NaN-NaN" )
    { this.Job_Posting_.Post_Filling_Date = ""}


    if(this.Job_Posting_.Job_Starting_Date!=null || this.Job_Posting_.Job_Starting_Date!=""||this.Job_Posting_.Job_Starting_Date!=undefined )
    { this.Job_Posting_.Job_Starting_Date = this.New_Date(new Date(moment(this.Job_Posting_.Job_Starting_Date).format("YYYY-MM-DD")));}

    if(this.Job_Posting_.Job_Starting_Date==null || this.Job_Posting_.Job_Starting_Date==""||this.Job_Posting_.Job_Starting_Date==undefined|| this.Job_Posting_.Job_Starting_Date=="NaN-NaN-NaN" )
    { this.Job_Posting_.Job_Starting_Date = ""}




  debugger
    this.Job_Posting_.By_User=Number(this.Login_User);

 if (this.Job_Posting_.Details == undefined || this.Job_Posting_.Details == null|| this.Job_Posting_.Details == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Job', Type: "3" } });
    return;
}

if (this.Job_Posting_.Description == undefined || this.Job_Posting_.Description == null|| this.Job_Posting_.Description == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Job Description', Type: "3" } });
    return;
}

// if (this.Job_Posting_.Available_Vacancy == undefined || this.Job_Posting_.Available_Vacancy == null|| this.Job_Posting_.Available_Vacancy == "") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Available Vacancy', Type: "3" } });
//     return;
// }

if (this.Job_Posting_.No_of_Positions == undefined || this.Job_Posting_.No_of_Positions == null|| this.Job_Posting_.No_of_Positions == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter No of Positions', Type: "3" } });
    return;
}

if (this.Job_Posting_.Salary == undefined || this.Job_Posting_.Salary == null|| this.Job_Posting_.Salary == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Salary ', Type: "3" } });
    return;
}


if (this.Job_Status_ == undefined || this.Job_Status_ == null|| this.Job_Status_ == 0) {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Job Status', Type: "3" } });
    return;
}


if (this.Job_Country_ == undefined || this.Job_Country_ == null|| this.Job_Country_ == 0) {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Job Country', Type: "3" } });
    return;
}

// if (this.Job_Posting_.Interview_Date == undefined || this.Job_Posting_.Interview_Date == null|| this.Job_Posting_.Interview_Date == "" ||this.Job_Posting_.Interview_Date=="NaN-NaN-NaN") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Choose Interview Date', Type: "3" } });
//     return;
// }


if (this.Job_Posting_.Location == undefined || this.Job_Posting_.Location == null|| this.Job_Posting_.Location == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Location', Type: "3" } });
    return;
}


if (this.Job_Posting_.Notes == undefined || this.Job_Posting_.Notes == null|| this.Job_Posting_.Notes == "") {
        
    const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Notes', Type: "3" } });
    return;
}


if (
    this.Employer_Search_T_ == undefined ||
    this.Employer_Search_T_ == null ||
    this.Employer_Search_T_.Employer_Id == undefined ||
    this.Employer_Search_T_.Employer_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Employer", Type: "3" },
    });
    return;
}


if (
    this.Job_Posting_.Max_Qualification_ == undefined ||
    this.Job_Posting_.Max_Qualification_== null || this.Job_Posting_.Max_Qualification_== ''
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Enter Qualification", Type: "3" },
    });
    return;
}


if (
    this.Job_Posting_.Experience_ == undefined ||
    this.Job_Posting_.Experience_ == null ||
    this.Job_Posting_.Experience_ == ''
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Enter Experience", Type: "3" },
    });
    return;
}

if (
    this.Job_Category_1_ == undefined ||
    this.Job_Category_1_ == null ||
    this.Job_Category_1_.Job_Category_Id == undefined ||
    this.Job_Category_1_.Job_Category_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Job Sector", Type: "3" },
    });
    return;
}

if (
    this.Job_1 == undefined ||
    this.Job_1 == null ||
    this.Job_1.Job_Id == undefined ||
    this.Job_1.Job_Id == 0
) {
    const dialogRef = this.dialogBox.open(DialogBox_Component, {
        panelClass: "Dialogbox-Class",
        data: { Message: "Select Job", Type: "3" },
    });
    return;
}



// if (this.Job_Posting_.Mandatory == undefined || this.Job_Posting_.Mandatory == null|| this.Job_Posting_.Mandatory == "") {
        
//     const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Enter Mandatory', Type: "3" } });
//     return;
// }



else{

    debugger
this.Job_Posting_.Qualification_Id=0
this.Job_Posting_.Qualification_Name=this.Job_Posting_.Max_Qualification_

this.Job_Posting_.Experience_Id=0
this.Job_Posting_.Experience_Name=this.Job_Posting_.Experience_ 

this.Job_Posting_.Employer_Id=this.Employer_Search_T_.Employer_Id
this.Job_Posting_.Employer_Name=this.Employer_Search_T_.Employer_Name

this.Job_Posting_.Job_Category_Id = this.Job_Category_1_.Job_Category_Id;
this.Job_Posting_.Job_Category_Name = this.Job_Category_1_.Job_Category_Name;
this.Job_Posting_.Job_Id = this.Job_1.Job_Id;
this.Job_Posting_.Job_Name = this.Job_1.Job_Name;

// document.getElementById("Save_Button").hidden=true;
console.log('this.Job_Posting_: ', this.Job_Posting_);
this.upload();
this.Job_Posting_Save =false;
this.issLoading=true;
debugger
this.Job_Posting_Service_.Save_Job_Posting(this.Job_Posting_).subscribe(Save_status => {
    debugger
    this.issLoading=false;
Save_status=Save_status[0];
if(Save_status!=undefined)
{
if (Number(Save_status[0].Job_Posting_Id_) > 0) 
{

debugger



    {

         if ( Save_status[0].Notification_Id_>0 ) {
            // if(Save_status[0].By_User_!=this.Login_User){
            var message = {
                 
                Student_Name: '',
                From_User_Name: Save_status[0].By_User_Name_,
                Notification_Type_Name: Save_status[0].Notification_Type_Name_,
                Entry_Type: Save_status[0].Entry_Type_,
                To_User: 0,
                Notification_Id: Save_status[0].Notification_Id_,
                Student_Id: 0,
                By_User:Save_status[0].By_User_,

            };
            this.socket.emit("new-message", message);
            // }
        }
    // const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
  

    }



const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Saved',Type:"false"}});
document.getElementById("Save_Button").hidden=false;

this.Search_Job_Posting();
this.Clr_Job_Posting();

}
}
else{
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
}
this.issLoading=false;
},
Rows => { 
    this.issLoading=false;
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}});
document.getElementById("Save_Button").hidden=false;
});

}
}
upload(){
    debugger
    this.issLoading=true
    console.log('   this.Job_Posting_: ',    this.Job_Posting_);
    if (!this.Job_Posting_.Document_file.length) {
        // const dialogRef = this.dialogBox.open(DialogBox_Component, { panelClass: 'Dialogbox-Class', data: { Message: 'Select Document', Type: '3' } });
        return;
    }
      this.Student_Service_.uploadJobFile(  this.Job_Posting_.Document_file.item(0)).then(
        res=>{
            debugger
            console.log('  this.Job_Posting_: ',   this.Job_Posting_);
              this.Job_Posting_.Image_Path =res['key']
            console.log('res: ', res);

        }
    )

}


clear_Document(){
	
	this.Job_Posting_.Job_Posting_Document_Id =0;
	this.Job_Posting_.Document_file = [];
						this.Job_Posting_.Image_File_Name = '';
						this.Job_Posting_.Image_Description = '';
}
display_Employer_Tab(Experience_e: Employer) {
    if (Experience_e) {
        return Experience_e.Employer_Name;
    }
}



Search_Employer_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Employer_Tab_Data == undefined || this.Employer_Tab_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Employer_Typeahead(Value).subscribe(
            (Rows) => {
                console.log('Rows: ', Rows);

                debugger
                if (Rows != null) {
                    this.Employer_Tab_Data = Rows[0];
                    this.Employer_Data = [];
                    for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
                        if (
                            this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Employer_Data.push(this.Employer_Tab_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Employer_Data = [];
        for (var i = 0; i < this.Employer_Tab_Data.length; i++) {
            if (
                this.Employer_Tab_Data[i].Employer_Name.toLowerCase().includes(Value)
            )
                this.Employer_Data.push(this.Employer_Tab_Data[i]);
        }
    }
}

Edit_Job_Posting(Job_Posting_e:Job_Posting,index)
{
    debugger
  
this.Entry_View=true;
this.Status_View=false;
this.Sub_Status_View=true;
this.Job_Posting_=Job_Posting_e;
this.Job_Posting_ = Object.assign({}, Job_Posting_e);

if(this.Job_Posting_.Job_Status=="Active"){this.Job_Status_ =1}
if(this.Job_Posting_.Job_Status=="Inactive"){this.Job_Status_ =2}
if(this.Job_Posting_.Job_Status=="Select"){this.Job_Status_ =0}



if(this.Job_Posting_.Job_Country=="United Kingdom"){this.Job_Country_ =1}
if(this.Job_Posting_.Job_Country=="Ireland"){this.Job_Country_ =2}
if(this.Job_Posting_.Job_Country=="Select"){this.Job_Country_ =0}

this.Job_Posting_.Interview_Date = this.New_Date(
new Date(moment(this.Job_Posting_.Interview_Date_s).format("YYYY-MM-DD")));

this.Job_Posting_.Post_Filling_Date = this.New_Date(
    new Date(moment(this.Job_Posting_.Post_Filling_Date_s).format("YYYY-MM-DD")));

    // this.Max_Qualification_Temp_.Max_Qualification_Id = this.Job_Posting_.Qualification_Id;
    // this.Max_Qualification_Temp_.Max_Qualification_Name = this.Job_Posting_.Qualification_Name;
    // this.Max_Qualification_ = Object.assign({}, this.Max_Qualification_Temp_);

    // this.Experience__Temp_.Experience_Id = this.Job_Posting_.Experience_Id;
    // this.Experience__Temp_.Experience_Name = this.Job_Posting_.Experience_Name;
    // this.Experience_ = Object.assign({}, this.Experience__Temp_);

    this.Job_Category_1_Temp_.Job_Category_Id = this.Job_Posting_.Job_Category_Id;
    this.Job_Category_1_Temp_.Job_Category_Name = this.Job_Posting_.Job_Category_Name;
    this.Job_Category_1_ = Object.assign({}, this.Job_Category_1_Temp_);

    this.Job_Temp_.Job_Id = this.Job_Posting_.Job_Id;
    this.Job_Temp_.Job_Name = this.Job_Posting_.Job_Name;
    this.Job_1 = Object.assign({}, this.Job_Temp_);

    // for (var i = 0; i < this.Employer_Data.length; i++) {
    //     if (
    //         this.Job_Posting_.Employer_Id ==
    //         this.Employer_Data[i].Employer_Id
    //     )
    //         this.Employer_ = this.Employer_Data[i];
    // }
    this.Employer_Temp_T.Employer_Id = this.Job_Posting_.Employer_Id;
    this.Employer_Temp_T.Employer_Name = this.Job_Posting_.Employer_Name;
    this.Employer_Search_T_ = Object.assign({}, this.Employer_Temp_T);
    console.log('Job_Posting_e: ', Job_Posting_e)
this.Job_Posting_.Image_File_Name=Job_Posting_e.Image_File_Name
 }




Get_Lead_Load_Data_ByUser(Login_User)
    {
        
        this.issLoading = true;
        this.Student_Service_.Get_Lead_Load_Data_ByUser(Login_User).subscribe(Rows => 
        
    {
     

   this.Users_Data = Rows[0].slice();
   this.Users_Temp.User_Details_Id = 0;
   this.Users_Temp.User_Details_Name = "All";
   this.Users_Data.unshift(Object.assign({},this.Users_Temp));
   this.User_Search = this.Users_Data[0];
   this.issLoading = false;
   
  
},
Rows => { 
const dialogRef = this.dialogBox.open( DialogBox_Component, {panelClass:'Dialogbox-Class',data:{Message:'Error Occured',Type:"2"}}); });
}


// Search_Job_Typeahead_1(event: any) {

//     debugger


//     var Value = "";
//     if (event.target == undefined) Value = "";
//     else{
//     if (event.target.value == "") Value = "";
//     else Value = event.target.value.toLowerCase();

//     if (event.target.value == undefined) Value = "";}

// if (
//     this.Job_Data == undefined ||
//     this.Job_Data.length == 0
// ) {
//     this.issLoading = true;
//     this.Student_Service_.Search_Job_Typeahead("").subscribe(
//         (Rows) => {
//             if (Rows != null) {

//                 debugger
//                 this.Job_Data = Rows[0];
//                 this.Job_Data_Filter = []
//                 for (var i = 0; i < this.Job_Data.length; i++) {
//                     if (
//                         this.Job_Data[i].Details.toLowerCase().includes(
//                             Value
//                         )
//                     )
//                         this.Job_Data_Filter.push(
//                             this.Job_Data[i]
//                         );
//                 }
//                 this.issLoading = false;
//             }
//         },
//         (Rows) => {
//             this.issLoading = false;
//         }
//     );
// }else {
//     this.Job_Data_Filter = [];
//     for (var i = 0; i < this.Job_Data.length; i++) {
//         if (
//             this.Job_Data[i].Details.toLowerCase().includes(Value)
//         )
//             this.Job_Data_Filter.push(this.Job_Data[i]);
//     }
// }
// // }
// }
// display_Job_1(Job_: Job_Posting) {
// if (Job_) {
//     return Job_.Details;
// }
// }

Search_Job_Typeahead_1(event: any) {

    debugger


    var Value = "";
    if (event.target == undefined) Value = "";
    else{
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();

    if (event.target.value == undefined) Value = "";}

if (
    this.Job_Data_2 == undefined ||
    this.Job_Data_2.length == 0
) {
    this.issLoading = true;
    this.Student_Service_.Search_Job_Typeahead_1("").subscribe(
        (Rows) => {
            if (Rows != null) {

                debugger
                this.Job_Data_2 = Rows[0];
                this.Job_Data_Filter_2 = []
                for (var i = 0; i < this.Job_Data_2.length; i++) {
                    if (
                        this.Job_Data_2[i].Job_Name.toLowerCase().includes(
                            Value
                        )
                    )
                        this.Job_Data_Filter_2.push(
                            this.Job_Data_2[i]
                        );
                }
                this.issLoading = false;
            }
        },
        (Rows) => {
            this.issLoading = false;
        }
    );
}else {
    this.Job_Data_Filter_2 = [];
    for (var i = 0; i < this.Job_Data_2.length; i++) {
        if (
            this.Job_Data_2[i].Job_Name.toLowerCase().includes(Value)
        )
            this.Job_Data_Filter_2.push(this.Job_Data_2[i]);
    }
}
// }
}
display_Job_1(Job_: Job) {
if (Job_) {
    return Job_.Job_Name;
}
}




Search_Job_Qualification_Typeahead(event: any) {
    debugger
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    this.Max_Qualification_Data=[]
    if (this.Max_Qualification_Data == undefined || this.Max_Qualification_Data.length == 0) {
        this.issLoading = true;
debugger
        this.Max_Qualification_Service_.Search_Job_Qualification_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Max_Qualification_Data = Rows[0];
                    this.Max_Qualification_Data_Filter = [];
                    for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
                        if (
                            this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value)
                        )
                            this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Max_Qualification_Data_Filter = [];
        for (var i = 0; i < this.Max_Qualification_Data.length; i++) {
            if (this.Max_Qualification_Data[i].Max_Qualification_Name.toLowerCase().includes(Value))
                this.Max_Qualification_Data_Filter.push(this.Max_Qualification_Data[i]);
        }
    }
}

display_Job_Qualification(Max_Qualification_e: Max_Qualification) 
{
    if (Max_Qualification_e) {
        
        return Max_Qualification_e.Max_Qualification_Name;
    }
}



Search_Experience_Typeahead(event: any) {
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
debugger
    if (this.Experience_Data == undefined || this.Experience_Data.length == 0) {
        this.issLoading = true;
        debugger
        this.University_Service_.Search_Experience_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Experience_Data = Rows[0];
                    this.Experience_Data_Filter = [];
                    for (var i = 0; i < this.Experience_Data.length; i++) {
                        if (
                            this.Experience_Data[i].Experience_Name.toLowerCase().includes(
                                Value
                            )
                        )
                            this.Experience_Data_Filter.push(this.Experience_Data[i]);
                    }
                }
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    } else {
        this.Experience_Data_Filter = [];
        for (var i = 0; i < this.Experience_Data.length; i++) {
            if (
                this.Experience_Data[i].Experience_Name.toLowerCase().includes(Value)
            )
                this.Experience_Data_Filter.push(this.Experience_Data[i]);
        }
    }
}
display_Experience(Experience_e: Experience) {
    if (Experience_e) {
        return Experience_e.Experience_Name;
    }
}


Get_Student_PageLoadData_Dropdowns() {
    this.Student_Service_.Get_Student_PageLoadData_Dropdowns().subscribe(
        (Rows) => {
            
          

            this.Employer_Data = Rows[24].slice();
            this.Employer_Temp.Employer_Id = 0;
            this.Employer_Temp.Employer_Name = "Select";
            this.Employer_Data.unshift(Object.assign({}, this.Employer_Temp));
            // this.Employer_ = this.Employer_Data[0];
            // this.Employer_Search_ =this.Employer_Data[0];


        },
        (Rows) => {
            const dialogRef = this.dialogBox.open(DialogBox_Component, {
                panelClass: "Dialogbox-Class",
                data: { Message: "Error Occured", Type: "2" },
            });
        }
    );
}

Search_Job_Category_Typeahead(event: any) {
		
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    // this.Job_Category_1_Data=[]

    if (this.Job_Category_1_Data == undefined || this.Job_Category_1_Data.length == 0) {
        this.issLoading = true;

        this.Job_Category_Service_.Search_Job_Category_Typeahead(Value).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Job_Category_1_Data = Rows[0];
                    this.Job_Category_1_Data_Filter = [];
                    for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
                        if (
                            this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value)
                        )
                            this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Job_Category_1_Data_Filter = [];
        for (var i = 0; i < this.Job_Category_1_Data.length; i++) {
            if (this.Job_Category_1_Data[i].Job_Category_Name.toLowerCase().includes(Value))
                this.Job_Category_1_Data_Filter.push(this.Job_Category_1_Data[i]);
        }
    }
}

display_Job_Category(Job_Category_e: Job_Category) 
{
    if (Job_Category_e) {
        return Job_Category_e.Job_Category_Name;
    }
}


Search_Job_Typeahead(event: any) {


    if (
        this.Job_Category_1_ == undefined ||
        this.Job_Category_1_ == null ||
        this.Job_Category_1_.Job_Category_Id == undefined ||
        this.Job_Category_1_.Job_Category_Id == 0
    ) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "Select Job Sector", Type: "3" },
        });
        return;
    }




    
    var Value = "";
    if (event.target.value == "") Value = "";
    else Value = event.target.value.toLowerCase();
    // this.Job_Data_1=[]
    if (this.Job_Data_1 == undefined || this.Job_Data_1.length == 0) {
        this.issLoading = true;
debugger
        this.Max_Qualification_Service_.Search_Job_Typeahead(Value,this.Job_Category_1_.Job_Category_Id).subscribe(
            (Rows) => {
                debugger
                if (Rows != null) {
                    this.Job_Data_1 = Rows[0];
                    this.Job_Filter = [];
                    for (var i = 0; i < this.Job_Data_1.length; i++) {
                        if (
                            this.Job_Data_1[i].Job_Name.toLowerCase().includes(Value)
                        )
                            this.Job_Filter.push(this.Job_Data_1[i]);
                    }
                }
                
                this.issLoading = false;
            },
            (Rows) => {
                this.issLoading = false;
            }
        );
    }  
    else {
        
        this.Job_Filter = [];
        for (var i = 0; i < this.Job_Data_1.length; i++) {
            if (this.Job_Data_1[i].Job_Name.toLowerCase().includes(Value))
                this.Job_Filter.push(this.Job_Data_1[i]);
        }
    }
}

display_Job(Job_e: Job) 
{
    if (Job_e) {
        
        return Job_e.Job_Name;
    }
}


File_Change_std_Doc(event: Event) {
    const file = (event.target as HTMLInputElement).files;
    const fileSizeInMB = file[0].size / (1024 * 1024); // Convert bytes to megabytes

    if (fileSizeInMB > 5) {
        const dialogRef = this.dialogBox.open(DialogBox_Component, {
            panelClass: "Dialogbox-Class",
            data: { Message: "File size exceeds 5 MB. Please select a smaller file.", Type: "3" },
          });         // You can also reset the input if needed
      // event.target.value = null;
    } else {
    this.file_b2b_changed=true
    const file = (event.target as HTMLInputElement).files;
    console.log('file: ', file);
    this.Job_Posting_.Document_file = file;
    this.Job_Posting_.Image_File_Name = file[0].name;
    }
}

Download_Documents(doc){
    debugger
    var bs = environment.FilePath;
    var s = bs + doc;
    window.open(s, "_blank");
}
sanitizeUrl(url: string): SafeResourceUrl {
    debugger
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
View_Documents(Photo) {
    debugger
    this.selectedPdfPreview=null
    var bs = environment.FilePath;
    var s = bs + Photo;
    
this.pdfload=false


this.selectedPdfPreview=this.sanitizeUrl(s)
console.log('this.selectedPdfPreview: ', this.selectedPdfPreview);
this.pdfload=true

}

}
