import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {B2B_AgenciesComponent}  from './B2B_Agencies.component';
describe('Refund_Approval', () => {
let component: B2B_AgenciesComponent;
let fixture: ComponentFixture<B2B_AgenciesComponent>;
beforeEach(async(() => {
TestBed.configureTestingModule({
declarations: [ B2B_AgenciesComponent ]
})
.compileComponents();
}));
beforeEach(() => {
fixture = TestBed.createComponent(B2B_AgenciesComponent);
component = fixture.componentInstance;
fixture.detectChanges();
});
it('should create', () => {
expect(component).toBeTruthy();
});
});

