import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Pending_Fees_ReportComponent } from './Pending_Fees_Report.component';


describe('Pending_Fees_ReportComponent', () => {
  let component: Pending_Fees_ReportComponent;
  let fixture: ComponentFixture<Pending_Fees_ReportComponent>;

  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [Pending_Fees_ReportComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Pending_Fees_ReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
